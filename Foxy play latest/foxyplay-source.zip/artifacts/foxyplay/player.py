"""
player.py — FoxyPlay Pro M3U8 Player + Multi-Source Extractor
=============================================================
Extractors:  Videasy · VidLink · PrimeSrc
Player:      HLS.js · Quality selector · PiP · Fullscreen · Speed
Proxy:       Cloudflare Worker — all segments routed through it
"""

from __future__ import annotations

import codecs
import json
import os
import re
import time
from base64 import b64decode as _b64dec
from urllib.parse import urlparse, urljoin, quote, parse_qs

import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel


# ══════════════════════════════════════════════════════════════════════════════
#  SHARED UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

CF_PROXY_BASE  = "https://foxy-doxy.andruilsyestems.workers.dev"
ENC_DEC_API    = "https://enc-dec.app/api"
TMDB_API_KEY   = os.environ.get("TMDB_API_KEY", "6fad3f86b8452ee232deb7977d7dcf58")
TMDB_API_BASE  = "https://api.themoviedb.org/3"
TMDB_IMG_BASE  = "https://image.tmdb.org/t/p/w185"
JIKAN_BASE     = "https://api.jikan.moe/v4"

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
)

class ExtractorError(Exception):
    pass

def _find_streams(obj):
    """Recursively walk JSON and collect .m3u8 / playlist URLs."""
    found, seen = [], set()
    def walk(node):
        if isinstance(node, dict):
            for v in node.values():
                if isinstance(v, str) and v.startswith("http") and v not in seen:
                    if ".m3u8" in v or "/master" in v or "playlist" in v:
                        found.append(v); seen.add(v)
                walk(v)
        elif isinstance(node, list):
            for it in node: walk(it)
    walk(obj)
    return found

def _find_streams_in_text(text: str):
    """Find m3u8 URLs inside raw HTML/JS text."""
    pattern = r'https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*'
    return list(dict.fromkeys(re.findall(pattern, text)))

def _get(url, headers, timeout=15):
    r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
    r.raise_for_status()
    return r

def _post(url, payload, headers, timeout=15):
    r = requests.post(url, json=payload, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r

def _api_unwrap(data, label):
    if not isinstance(data, dict):
        raise ExtractorError(f"[{label}] invalid response type")
    if data.get("status") != 200:
        raise ExtractorError(
            f"[{label}] status={data.get('status')} err={data.get('error','unknown')}"
        )
    return data["result"]


# ══════════════════════════════════════════════════════════════════════════════
#  1. VIDEASY EXTRACTOR
# ══════════════════════════════════════════════════════════════════════════════

VIDEASY_SERVERS = [
    ("mb-flix","api"), ("1movies","api"), ("moviebox","api"), ("cdn","api"),
    ("primesrcme","api"), ("primewire","api2"), ("m4uhd","api2"),
    ("hdmovie","api"), ("lamovie","api"), ("superflix","api"),
    ("cuevana","api2"), ("overflix","api2"), ("visioncine","api"), ("meine","api"),
]

def extract_videasy(movie_url: str) -> dict:
    parsed = urlparse(movie_url)
    if parsed.netloc.lower() != "player.videasy.net":
        raise ExtractorError("Only player.videasy.net URLs are supported")
    parts = [p for p in parsed.path.strip("/").split("/") if p]
    if len(parts) < 2 or parts[0] not in ("movie", "tv"):
        raise ExtractorError(
            "URL must be: https://player.videasy.net/movie/<tmdb_id> "
            "or https://player.videasy.net/tv/<tmdb_id>/<season>/<episode>"
        )
    media_type = parts[0]
    tmdb_id    = parts[1]
    season     = parts[2] if len(parts) > 2 else "1"
    episode    = parts[3] if len(parts) > 3 else "1"

    headers = {
        "User-Agent": DEFAULT_UA,
        "Accept": "*/*",
        "Origin": "https://cineby.sc",
        "Referer": "https://cineby.sc/",
    }
    errors = []
    for server, api_sub in VIDEASY_SERVERS:
        if media_type == "tv":
            api_url = (
                f"https://{api_sub}.videasy.net/{server}/sources-with-title"
                f"?mediaType=tv&tmdbId={tmdb_id}&season={season}&episode={episode}"
            )
        else:
            api_url = (
                f"https://{api_sub}.videasy.net/{server}/sources-with-title"
                f"?mediaType=movie&tmdbId={tmdb_id}"
            )
        try:
            r = _get(api_url, headers)
            encrypted = r.text
            if not encrypted or len(encrypted.strip()) < 10:
                errors.append(f"{server}: empty"); continue
            dec = _post(
                f"{ENC_DEC_API}/dec-videasy",
                {"text": encrypted, "id": str(tmdb_id)},
                {"User-Agent": DEFAULT_UA, "Content-Type": "application/json"},
            )
            decrypted = _api_unwrap(dec.json(), f"dec/{server}")
            streams = _find_streams(decrypted)
            if streams:
                return {"tmdb_id": tmdb_id, "server": server, "streams": streams, "source": "videasy"}
        except (requests.RequestException, ExtractorError) as e:
            errors.append(f"{server}: {e}")
        except Exception as e:
            errors.append(f"{server}: {e}")
    raise ExtractorError("All Videasy servers failed.\n" + "\n".join(errors[-6:]))


# ══════════════════════════════════════════════════════════════════════════════
#  2. VIDLINK EXTRACTOR
# ══════════════════════════════════════════════════════════════════════════════

VIDLINK_HEADERS = {
    "User-Agent": DEFAULT_UA,
    "Origin": "https://vidlink.pro",
    "Referer": "https://vidlink.pro/",
    "Accept": "application/json",
}

def _vidlink_validate(data: dict, path: str):
    if data.get("status") != 200:
        raise ExtractorError(
            f"VidLink API error at {path} | status={data.get('status')} | "
            f"error={data.get('error', 'unknown')}"
        )
    return data["result"]

def _vidlink_encrypt_tmdb_id(tmdb_id: str) -> str:
    url = f"{ENC_DEC_API}/enc-vidlink?text={tmdb_id}"
    r = requests.get(url, timeout=20)
    r.raise_for_status()
    return _vidlink_validate(r.json(), url)

def _vidlink_parse_url(page_url: str) -> dict:
    parsed = urlparse(page_url)
    netloc = parsed.netloc.lower()
    if netloc not in {"vidlink.pro", "www.vidlink.pro"}:
        raise ExtractorError("Only vidlink.pro URLs are supported")
    parts = [p for p in parsed.path.strip("/").split("/") if p]
    if not parts:
        raise ExtractorError("Unsupported VidLink URL format")
    if parts[0] == "movie":
        if len(parts) < 2:
            raise ExtractorError("Missing TMDB ID in VidLink movie URL")
        return {"type": "movie", "tmdb_id": parts[1], "season": None, "episode": None}
    if parts[0] == "tv":
        if len(parts) < 4:
            raise ExtractorError("VidLink TV URL must be: /tv/<id>/<season>/<episode>")
        return {"type": "tv", "tmdb_id": parts[1], "season": parts[2], "episode": parts[3]}
    raise ExtractorError("Unsupported VidLink URL format")

def _vidlink_build_api_url(content_type: str, enc_id: str, season=None, episode=None) -> str:
    if content_type == "movie":
        return f"https://vidlink.pro/api/b/movie/{enc_id}"
    if content_type == "tv":
        if not season or not episode:
            raise ExtractorError("Season and episode required for TV")
        return f"https://vidlink.pro/api/b/tv/{enc_id}/{season}/{episode}"
    raise ExtractorError("Invalid VidLink content type")

def extract_vidlink(movie_url: str) -> dict:
    info = _vidlink_parse_url(movie_url)
    tmdb_id = info["tmdb_id"]
    try:
        encrypted_id = _vidlink_encrypt_tmdb_id(tmdb_id)
    except Exception as e:
        raise ExtractorError(f"VidLink encrypt step failed: {e}")
    api_url = _vidlink_build_api_url(
        info["type"], encrypted_id, info["season"], info["episode"]
    )
    try:
        r = requests.get(api_url, headers=VIDLINK_HEADERS, timeout=20)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        raise ExtractorError(f"VidLink API request failed: {e}")
    try:
        playlist = data["stream"]["playlist"]
    except (KeyError, TypeError) as e:
        raise ExtractorError(f"VidLink: could not find stream.playlist in response: {e}")
    if not playlist:
        raise ExtractorError("VidLink: empty playlist URL returned")
    return {
        "tmdb_id": tmdb_id,
        "server": "vidlink.pro",
        "streams": [playlist],
        "source": "vidlink",
    }


# ══════════════════════════════════════════════════════════════════════════════
#  3. PRIMESRC EXTRACTOR
# ══════════════════════════════════════════════════════════════════════════════

PRIMESRC_HEADERS = {
    "User-Agent": DEFAULT_UA,
    "Accept": "*/*",
    "Origin": "https://primesrc.me",
    "Referer": "https://primesrc.me/",
}

def _primesrc_parse_url(url: str) -> dict:
    if url.strip().isdigit():
        return {"type": "movie", "imdb_id": None, "tmdb_id": url.strip(), "season": None, "episode": None}

    parsed = urlparse(url)
    qs = parse_qs(parsed.query)

    def first(k):
        return qs.get(k, [None])[0]

    path = parsed.path.lower()
    if "/movie" in path:
        media_type = "movie"
    elif "/tv" in path or "/series" in path or "/anime" in path:
        media_type = "tv"
    else:
        media_type = first("type") or "movie"

    return {
        "type":    media_type,
        "imdb_id": first("imdb"),
        "tmdb_id": first("tmdb"),
        "season":  first("season"),
        "episode": first("episode"),
    }


def _primesrc_fetch_servers(params: dict) -> list:
    imdb_id = params.get("imdb_id")
    tmdb_id = params.get("tmdb_id")
    media   = params["type"]
    season  = params.get("season")
    episode = params.get("episode")

    if imdb_id:
        id_param = f"imdb={imdb_id}"
    elif tmdb_id:
        id_param = f"tmdb={tmdb_id}"
    else:
        raise ExtractorError("PrimeSrc: no IMDB or TMDB id found in URL")

    if media == "movie":
        api_url = f"https://primesrc.me/api/v1/s?{id_param}&type=movie"
    else:
        if not season or not episode:
            raise ExtractorError("PrimeSrc: TV URL needs season and episode parameters")
        api_url = (
            f"https://primesrc.me/api/v1/s?{id_param}"
            f"&season={season}&episode={episode}&type=tv"
        )

    try:
        resp = requests.get(api_url, headers=PRIMESRC_HEADERS, timeout=20).json()
    except Exception as e:
        raise ExtractorError(f"PrimeSrc: server list request failed: {e}")

    servers = resp.get("servers", [])
    if not servers:
        raise ExtractorError("PrimeSrc: no servers returned from API")
    return servers


def _primesrc_resolve_key(key: str) -> str | None:
    embed_api = f"https://primesrc.me/api/v1/l?key={key}"
    solve_url = f"{ENC_DEC_API}/solve-primesrc?url={quote(embed_api)}"
    try:
        data = requests.get(solve_url, headers=PRIMESRC_HEADERS, timeout=15).json()
        if data.get("status") != 200:
            return None
        return data["result"]
    except Exception:
        return None


def _voe_decrypt(voe_embed_url: str) -> str | None:
    try:
        domain  = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(voe_embed_url))
        session = requests.Session()
        session.headers.update({
            "Referer":    domain,
            "User-Agent": DEFAULT_UA,
        })
        html = session.get(voe_embed_url, timeout=20).text
        if 'Redirecting...' in html:
            redirect_url = re.search(r"href\s*=\s*'(.*?)';", html).group(1)
            html = session.get(redirect_url, timeout=20).text

        soup       = BeautifulSoup(html, 'html.parser')
        script_tag = soup.find('script', attrs={'type': 'application/json'})
        if not script_tag:
            return None

        obfuscated = script_tag.string
        encoded    = re.search(r'\["(.*?)"\]', obfuscated).group(1)
        decoded    = codecs.decode(encoded, 'rot_13')

        for p in ["@$", "^^", "~@", "%?", "*~", "!!", "#&"]:
            decoded = re.sub(re.escape(p), "_", decoded)
        decoded = decoded.replace("_", "")
        decoded = _b64dec(decoded).decode()
        decoded = ''.join(chr(ord(c) - 3) for c in decoded)[::-1]
        decoded = _b64dec(decoded).decode()
        data    = json.loads(decoded)
        return data.get('source')
    except Exception:
        return None


def extract_primesrc(movie_url: str) -> dict:
    params  = _primesrc_parse_url(movie_url)
    servers = _primesrc_fetch_servers(params)

    tmdb_id = params.get("tmdb_id") or params.get("imdb_id") or "unknown"
    streams  = []
    server_name = "primesrc.me"

    for srv in servers:
        key  = srv.get("key", "")
        name = str(srv.get("name") or "unknown")
        if not key:
            continue
        link = _primesrc_resolve_key(key)
        if link and link.startswith("http"):
            if ".m3u8" in link or "/master" in link:
                if link not in streams:
                    streams.append(link)
                    server_name = name
            elif "voe.sx" in link:
                m3u8 = _voe_decrypt(link)
                if m3u8 and m3u8 not in streams:
                    streams.append(m3u8)
                    server_name = name

    if not streams:
        raise ExtractorError(
            "PrimeSrc: no HLS streams could be extracted from any server. "
            "Doodstream/other non-HLS hosts are not supported via this player."
        )

    return {
        "tmdb_id": tmdb_id,
        "server":  server_name,
        "streams": streams,
        "source":  "primesrc",
    }


# ══════════════════════════════════════════════════════════════════════════════
#  TMDB HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _tmdb_headers():
    hdrs = {"Accept": "application/json"}
    if TMDB_API_KEY.startswith("eyJ"):
        hdrs["Authorization"] = f"Bearer {TMDB_API_KEY}"
    return hdrs

def tmdb_search(query: str, media_type: str = "movie", page: int = 1) -> dict:
    if not TMDB_API_KEY:
        raise ExtractorError("TMDB_API_KEY is not configured")
    url = f"{TMDB_API_BASE}/search/{media_type}"
    params: dict = {"query": query, "page": page, "include_adult": "false"}
    if not TMDB_API_KEY.startswith("eyJ"):
        params["api_key"] = TMDB_API_KEY
    r = requests.get(url, headers=_tmdb_headers(), params=params, timeout=10)
    r.raise_for_status()
    data = r.json()
    results = []
    for item in data.get("results", [])[:12]:
        poster = item.get("poster_path")
        results.append({
            "id":       item["id"],
            "title":    item.get("title") or item.get("name") or "Unknown",
            "year":     (item.get("release_date") or item.get("first_air_date") or "")[:4],
            "rating":   round(item.get("vote_average", 0), 1),
            "overview": (item.get("overview") or "")[:200],
            "poster":   f"{TMDB_IMG_BASE}{poster}" if poster else None,
            "type":     media_type,
        })
    return {"results": results, "total": data.get("total_results", 0), "page": page}


# ══════════════════════════════════════════════════════════════════════════════
#  JIKAN / MAL ANIME SEARCH  (used by MegaPlay + VidWish only)
# ══════════════════════════════════════════════════════════════════════════════

def jikan_search(query: str, page: int = 1) -> dict:
    time.sleep(0.4)  # Jikan rate-limit
    url = f"{JIKAN_BASE}/anime"
    params: dict = {"q": query, "page": page, "limit": 12}
    r = requests.get(url, params=params, timeout=15)
    r.raise_for_status()
    data = r.json()
    results = []
    for item in data.get("data", []):
        img = (item.get("images") or {}).get("jpg", {}).get("large_image_url")
        year_raw = (item.get("aired") or {}).get("prop", {}).get("from", {}).get("year")
        results.append({
            "mal_id":   item["mal_id"],
            "title":    item.get("title_english") or item.get("title") or "Unknown",
            "year":     str(item.get("year") or year_raw or ""),
            "rating":   round(item.get("score") or 0, 1),
            "episodes": item.get("episodes") or 1,
            "poster":   img,
            "type":     "anime",
        })
    total = (data.get("pagination") or {}).get("items", {}).get("total", 0)
    return {"results": results, "total": total, "page": page}


# ══════════════════════════════════════════════════════════════════════════════
#  EXTRACTOR REGISTRY
# ══════════════════════════════════════════════════════════════════════════════

EXTRACTORS = {
    "videasy":  extract_videasy,
    "vidlink":  extract_vidlink,
    "primesrc": extract_primesrc,
}

SOURCE_HEADERS = {
    "videasy": {
        "Referer": "https://player.videasy.net/",
        "Origin":  "https://player.videasy.net",
    },
    "vidlink": {
        "Referer": "https://vidlink.pro/",
        "Origin":  "https://vidlink.pro",
    },
    "primesrc": {
        "Referer": "https://primesrc.me/",
        "Origin":  "https://primesrc.me",
    },
}


# ══════════════════════════════════════════════════════════════════════════════
#  FRONTEND HTML
# ══════════════════════════════════════════════════════════════════════════════

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>FoxyPlay — Pro M3U8 Player</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;700;800;900&display=swap" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js"></script>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0b0c14;--s1:#0f1020;--s2:#13152a;--s3:#181a30;--s4:#1e2038;
  --border:rgba(255,255,255,.06);--border2:rgba(255,255,255,.12);
  --text:#e2e8f8;--muted:#7080a0;--muted2:#353a55;
  --acc:#8B5CF6;--acc2:#6d3ed4;
  --gold:#f0c060;--gold2:#c9923a;
  --green:#34d399;--red:#e05070;--cyan:#38bdf8;
  --purple:#8B5CF6;--orange:#f07040;
  --r:16px;--r2:10px;--r3:7px;
  --c-videasy:#f0c060;
  --c-vidlink:#a06cf0;
  --c-primesrc:#34d399;
}

html,body{height:100%;background:var(--bg);color:var(--text);
  font-family:'Syne',sans-serif;overflow-x:hidden;font-size:15px}

body::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background:
    radial-gradient(ellipse at 15% 15%,rgba(139,92,246,.18) 0,transparent 50%),
    radial-gradient(ellipse at 85% 75%,rgba(139,92,246,.10) 0,transparent 45%),
    radial-gradient(ellipse at 50% 100%,rgba(56,189,248,.06) 0,transparent 50%);}
body::after{content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background-image:
    linear-gradient(rgba(255,255,255,.012) 1px,transparent 1px),
    linear-gradient(90deg,rgba(255,255,255,.012) 1px,transparent 1px);
  background-size:48px 48px;}

.shell{position:relative;z-index:1;max-width:1200px;margin:0 auto;
  padding:28px 24px 90px;display:flex;flex-direction:column;gap:22px}

/* ── top bar ── */
.topbar{display:flex;align-items:center;gap:14px;padding-bottom:4px}
.brand{display:flex;align-items:center;gap:12px;cursor:pointer}
.brand:hover .brand-name{opacity:.85}
.brand:hover .brand-mark{box-shadow:0 0 34px rgba(139,92,246,.65)}
.brand-mark{
  width:42px;height:42px;border-radius:12px;
  background:linear-gradient(135deg,#8B5CF6,#6d3ed4);
  display:grid;place-items:center;font-size:19px;
  box-shadow:0 0 26px rgba(139,92,246,.45)}
.brand-name{font-size:1.5rem;font-weight:900;letter-spacing:-.02em;
  background:linear-gradient(90deg,#fff 0%,#c4b5fd 55%,#8B5CF6 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.brand-sub{font-family:'Space Mono',monospace;font-size:.55rem;color:var(--muted);
  letter-spacing:.14em;text-transform:uppercase;margin-top:1px}
.tb-spacer{flex:1}
.pill{padding:5px 13px;border-radius:20px;border:1px solid var(--border2);
  background:rgba(255,255,255,.04);font-size:.6rem;letter-spacing:.08em;
  text-transform:uppercase;font-family:'Space Mono',monospace;color:var(--muted);
  display:inline-flex;align-items:center;gap:6px}
.pill.live{border-color:rgba(52,211,153,.3);color:var(--green);
  animation:pulse-border 2.5s ease-in-out infinite}
@keyframes pulse-border{0%,100%{border-color:rgba(52,211,153,.3)}50%{border-color:rgba(52,211,153,.7)}}
.pill.btn{cursor:pointer;transition:all .15s}
.pill.btn:hover{color:var(--acc);border-color:rgba(139,92,246,.5);background:rgba(139,92,246,.09)}
.dot{width:6px;height:6px;border-radius:50%;background:currentColor;
  animation:blink 1.6s step-end infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}

/* ── url row ── */
.url-card{background:var(--s1);border:1px solid var(--border);
  border-radius:var(--r);padding:14px;display:flex;gap:10px;flex-wrap:wrap;
  box-shadow:0 4px 24px rgba(0,0,0,.35)}
.url-input{flex:1;min-width:260px;padding:13px 16px;
  background:var(--s3);border:1px solid var(--border);border-radius:var(--r2);
  color:var(--text);font-family:'Space Mono',monospace;font-size:.82rem;
  outline:none;transition:border-color .18s,box-shadow .18s}
.url-input:focus{border-color:var(--acc);box-shadow:0 0 0 3px rgba(139,92,246,.15)}
.url-input::placeholder{color:var(--muted2)}

/* ── buttons ── */
.btn{border:none;cursor:pointer;font-family:'Syne',sans-serif;
  font-weight:700;letter-spacing:.05em;text-transform:uppercase;
  transition:all .16s;display:inline-flex;align-items:center;
  justify-content:center;gap:7px;border-radius:var(--r2);white-space:nowrap}
.btn-primary{
  background:linear-gradient(135deg,#8B5CF6,#6d3ed4);
  color:#fff;padding:13px 22px;font-size:.76rem;
  box-shadow:0 4px 18px rgba(139,92,246,.35)}
.btn-primary:hover{filter:brightness(1.15);transform:translateY(-1px);
  box-shadow:0 6px 24px rgba(139,92,246,.5)}
.btn-ghost{background:rgba(255,255,255,.05);color:var(--text);
  border:1px solid var(--border2);padding:10px 16px;font-size:.7rem}
.btn-ghost:hover{border-color:var(--acc);color:var(--acc);background:rgba(139,92,246,.08)}
.btn-sm{padding:7px 12px;font-size:.62rem}
.btn-red{background:rgba(224,80,106,.1);color:var(--red);
  border:1px solid rgba(224,80,106,.25);padding:9px 14px;font-size:.68rem}
.btn-red:hover{background:rgba(224,80,106,.2)}
.btn:disabled{opacity:.35;cursor:not-allowed;transform:none!important}

/* ── extractor buttons ── */
.ext-row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.ext-label{font-family:'Space Mono',monospace;font-size:.58rem;
  text-transform:uppercase;letter-spacing:.1em;color:var(--muted);
  flex-basis:100%;margin-bottom:2px}

.ext-btn{
  flex:1;min-width:130px;
  border:none;cursor:pointer;font-family:'Syne',sans-serif;
  font-weight:800;font-size:.74rem;letter-spacing:.06em;text-transform:uppercase;
  padding:13px 18px;border-radius:var(--r2);
  display:inline-flex;align-items:center;justify-content:center;gap:8px;
  transition:all .18s;position:relative;overflow:hidden}
.ext-btn::before{
  content:'';position:absolute;inset:0;opacity:0;
  background:linear-gradient(135deg,rgba(255,255,255,.15),rgba(255,255,255,0));
  transition:opacity .18s}
.ext-btn:hover::before{opacity:1}
.ext-btn:hover{transform:translateY(-2px)}
.ext-btn:active{transform:translateY(0)}

.ext-btn.videasy{
  background:linear-gradient(135deg,#f0c060,#c9923a);color:#1a0e00;
  box-shadow:0 4px 18px rgba(240,192,96,.28)}
.ext-btn.vidlink{
  background:linear-gradient(135deg,#a06cf0,#7040c8);color:#fff;
  box-shadow:0 4px 18px rgba(160,108,240,.28)}
.ext-btn.primesrc{
  background:linear-gradient(135deg,#36d98a,#1a9e5c);color:#001a0d;
  box-shadow:0 4px 18px rgba(54,217,138,.28)}

.ext-btn .ext-icon{font-size:1rem}
.ext-btn .ext-spinner{display:none;width:14px;height:14px;
  border:2px solid rgba(255,255,255,.3);border-top-color:currentColor;
  border-radius:50%;animation:spin .7s linear infinite}
.ext-btn.loading .ext-icon{display:none}
.ext-btn.loading .ext-spinner{display:inline-block}
.ext-btn.loading{opacity:.7;cursor:wait;transform:none!important}

@keyframes spin{to{transform:rotate(360deg)}}

/* ── player ── */
.player-card{background:#000;border:1px solid var(--border);
  border-radius:var(--r);overflow:hidden;
  box-shadow:0 24px 70px rgba(0,0,0,.6);position:relative}
.player-wrap{position:relative;width:100%;aspect-ratio:16/9;background:#000;
  display:flex;align-items:center;justify-content:center}
#video{width:100%;height:100%;display:block;background:#000}
.player-overlay{position:absolute;inset:0;display:flex;
  flex-direction:column;align-items:center;justify-content:center;
  gap:16px;color:var(--muted);pointer-events:none;text-align:center;padding:24px;
  background:radial-gradient(circle at center,rgba(13,18,32,.6),rgba(4,6,13,.9))}
.player-overlay svg{opacity:.2;filter:drop-shadow(0 0 20px var(--acc))}
.player-overlay .ov-title{font-size:1.1rem;font-weight:800;color:var(--text);opacity:.5}
.player-overlay p{font-family:'Space Mono',monospace;font-size:.72rem;
  line-height:1.7;color:var(--muted)}
.player-overlay.gone{display:none}

.loader{position:absolute;inset:0;display:none;align-items:center;
  justify-content:center;background:rgba(0,0,0,.6);z-index:5;
  backdrop-filter:blur(4px)}
.loader.vis{display:flex}
.spinner{width:48px;height:48px;border:3px solid rgba(255,255,255,.1);
  border-top-color:var(--acc);border-radius:50%;animation:spin .75s linear infinite}

.ctrl-bar{padding:12px 18px;background:var(--s1);
  border-top:1px solid var(--border);display:flex;align-items:center;
  gap:10px;flex-wrap:wrap}
.ctrl-info{flex:1;min-width:0;display:flex;align-items:center;gap:10px}
.ctrl-title{font-size:.76rem;font-family:'Space Mono',monospace;
  color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.src-badge{padding:2px 8px;border-radius:4px;font-size:.58rem;
  font-family:'Space Mono',monospace;font-weight:700;letter-spacing:.05em;
  text-transform:uppercase;flex-shrink:0}
.ctrl-stats{font-family:'Space Mono',monospace;font-size:.62rem;
  color:var(--muted2);white-space:nowrap}
.qsel{background:var(--s3);border:1px solid var(--border2);color:var(--text);
  border-radius:var(--r3);padding:6px 10px;font-family:'Space Mono',monospace;
  font-size:.68rem;cursor:pointer;outline:none;transition:border-color .15s}
.qsel:focus{border-color:var(--acc)}

/* ── status ── */
.status-card{display:none;padding:13px 18px;border-radius:var(--r2);
  font-family:'Space Mono',monospace;font-size:.73rem;line-height:1.6}
.status-card.vis{display:block;animation:fadeUp .3s ease}
.status-card.info{background:rgba(79,142,255,.07);border:1px solid rgba(79,142,255,.22);color:var(--acc)}
.status-card.ok{background:rgba(54,217,138,.06);border:1px solid rgba(54,217,138,.22);color:var(--green)}
.status-card.err{background:rgba(224,80,106,.06);border:1px solid rgba(224,80,106,.22);color:var(--red)}
.status-card pre{white-space:pre-wrap;word-break:break-word;font-size:.65rem;
  margin-top:7px;color:var(--muted);opacity:.8}

/* ── streams list ── */
.streams-card{display:none;background:var(--s1);border:1px solid var(--border);
  border-radius:var(--r);overflow:hidden}
.streams-card.vis{display:block;animation:fadeUp .3s ease}
.streams-hdr{padding:13px 18px;border-bottom:1px solid var(--border);
  background:var(--s2);display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.streams-hdr h3{font-size:.76rem;text-transform:uppercase;
  letter-spacing:.1em;flex:1;font-weight:700}
.tag{font-family:'Space Mono',monospace;font-size:.6rem;
  padding:3px 9px;border-radius:4px;font-weight:700}
.tag.green{background:rgba(54,217,138,.1);border:1px solid rgba(54,217,138,.25);color:var(--green)}
.tag.acc{background:rgba(79,142,255,.1);border:1px solid rgba(79,142,255,.25);color:var(--acc)}
.sitem{padding:10px 16px;border-top:1px solid var(--border);
  display:flex;align-items:center;gap:8px;transition:background .12s}
.sitem:first-child{border-top:none}
.sitem:hover{background:var(--s2)}
.sitem .num{font-family:'Space Mono',monospace;font-size:.6rem;
  color:var(--acc);width:20px;flex-shrink:0}
.sitem .surl{flex:1;font-family:'Space Mono',monospace;font-size:.64rem;
  color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sitem .acts{display:flex;gap:5px;flex-shrink:0}

/* ── MODAL ── */
.modal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.78);
  z-index:50;backdrop-filter:blur(10px);align-items:flex-start;
  justify-content:center;padding:56px 20px 20px;overflow-y:auto}
.modal-bg.vis{display:flex}
.modal{background:var(--s1);border:1px solid var(--border2);
  border-radius:var(--r);width:100%;max-width:580px;
  box-shadow:0 30px 90px rgba(0,0,0,.7);animation:slideUp .22s ease}
@keyframes slideUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
.mhdr{padding:16px 22px;border-bottom:1px solid var(--border);
  background:var(--s2);display:flex;align-items:center;gap:11px;border-radius:var(--r) var(--r) 0 0}
.mhdr h3{flex:1;font-size:1.05rem;font-weight:800;color:var(--text)}
.mbody{padding:22px}
.frm-grp{margin-bottom:17px}
.frm-grp:last-child{margin-bottom:0}
.frm-grp label{display:block;font-size:.6rem;text-transform:uppercase;
  letter-spacing:.1em;color:var(--muted);font-family:'Space Mono',monospace;
  margin-bottom:6px;font-weight:700}
.frm-grp input,.frm-grp textarea{width:100%;padding:10px 13px;
  background:var(--s3);border:1px solid var(--border);border-radius:var(--r3);
  color:var(--text);font-family:'Space Mono',monospace;font-size:.78rem;
  outline:none;resize:vertical;transition:border-color .15s}
.frm-grp input:focus,.frm-grp textarea:focus{border-color:var(--acc)}
.frm-grp textarea{min-height:64px;font-size:.68rem;line-height:1.55}
.frm-note{font-size:.58rem;color:var(--muted2);
  font-family:'Space Mono',monospace;margin-top:5px;line-height:1.55}
.frm-note code{background:var(--s3);padding:1px 5px;border-radius:3px;color:var(--muted)}
.mftr{padding:14px 22px;border-top:1px solid var(--border);
  background:var(--s2);display:flex;gap:8px;justify-content:flex-end;
  flex-wrap:wrap;border-radius:0 0 var(--r) var(--r)}

.src-accent-videasy  .mhdr{border-top:3px solid var(--c-videasy)}
.src-accent-vidlink  .mhdr{border-top:3px solid var(--c-vidlink)}
.src-accent-primesrc .mhdr{border-top:3px solid var(--c-primesrc)}

/* ── samples ── */
.samples{display:flex;gap:8px;flex-wrap:wrap}
.sample-chip{padding:4px 12px;border-radius:14px;border:1px solid var(--border2);
  background:var(--s2);font-family:'Space Mono',monospace;font-size:.6rem;
  color:var(--muted);cursor:pointer;transition:all .15s}
.sample-chip:hover{color:var(--gold);border-color:rgba(240,192,96,.4);
  background:rgba(240,192,96,.06)}

/* ── divider ── */
.divider{display:flex;align-items:center;gap:10px}
.divider::before,.divider::after{content:'';flex:1;height:1px;background:var(--border)}
.divider span{font-family:'Space Mono',monospace;font-size:.58rem;
  color:var(--muted2);letter-spacing:.1em;text-transform:uppercase}

.fade{animation:fadeUp .3s ease}
@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}

@media(max-width:760px){
  .shell{padding:14px 12px 60px;gap:14px}
  .ext-btn{min-width:calc(50% - 5px);flex:none}
  .url-card{padding:10px;gap:8px}
  .btn-primary{flex:1}
}
@media(max-width:480px){
  .ext-btn{min-width:100%}
  .brand-name{font-size:1.2rem}
}

/* ── SEARCH VIEW ── */
#player-view{display:flex;flex-direction:column;gap:20px}
#search-view{display:none;flex-direction:column;gap:0}
#search-view.vis{display:flex}

/* hero search bar */
.sv-hero{
  position:sticky;top:0;z-index:10;
  background:rgba(11,12,20,.96);backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
  padding:18px 0 14px}
.sv-hero-inner{display:flex;flex-direction:column;gap:12px}
.sv-search-row{display:flex;gap:10px;align-items:center}
.sv-input{
  flex:1;padding:14px 20px;
  background:var(--s2);border:1.5px solid var(--border2);border-radius:var(--r);
  color:var(--text);font-family:'Syne',sans-serif;font-size:.95rem;font-weight:600;
  outline:none;transition:border-color .18s,box-shadow .18s}
.sv-input:focus{border-color:var(--acc);box-shadow:0 0 0 3px rgba(139,92,246,.18)}
.sv-input::placeholder{color:var(--muted2);font-weight:400}
.sv-tabs{display:flex;gap:6px;align-items:center}
.stab{padding:8px 18px;border-radius:24px;border:1.5px solid var(--border2);
  background:transparent;color:var(--muted);font-family:'Syne',sans-serif;
  font-size:.72rem;font-weight:700;letter-spacing:.04em;cursor:pointer;
  transition:all .18s;text-transform:uppercase}
.stab.active{background:rgba(139,92,246,.18);border-color:rgba(139,92,246,.55);
  color:#c4b5fd;box-shadow:0 0 14px rgba(139,92,246,.2)}
.stab:hover:not(.active){color:var(--text);border-color:var(--border2);
  background:rgba(255,255,255,.04)}
.sv-back{margin-left:auto}

/* poster grid */
.poster-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(160px,1fr));
  gap:16px;padding:20px 0 80px}
.poster-card{
  position:relative;border-radius:var(--r);overflow:hidden;
  background:var(--s2);border:1px solid var(--border);
  transition:all .24s;display:flex;flex-direction:column;cursor:pointer}
.poster-card:hover{border-color:rgba(139,92,246,.55);transform:translateY(-5px);
  box-shadow:0 20px 50px rgba(0,0,0,.7),0 0 0 1px rgba(139,92,246,.2)}
.poster-img-wrap{position:relative;aspect-ratio:2/3;background:var(--s3);overflow:hidden;flex-shrink:0}
.poster-img-wrap img{width:100%;height:100%;object-fit:cover;transition:transform .35s;display:block}
.poster-card:hover .poster-img-wrap img{transform:scale(1.07)}
.poster-ph{width:100%;height:100%;display:flex;align-items:center;
  justify-content:center;font-size:2.8rem;color:var(--muted2)}
.poster-type-badge{position:absolute;top:8px;left:8px;padding:2px 8px;
  border-radius:5px;font-family:'Space Mono',monospace;font-size:.48rem;
  font-weight:700;letter-spacing:.06em;text-transform:uppercase;
  background:rgba(0,0,0,.65);backdrop-filter:blur(4px);color:var(--muted)}
.poster-type-badge.movie{background:rgba(56,189,248,.2);color:#38bdf8;border:1px solid rgba(56,189,248,.35)}
.poster-type-badge.tv{background:rgba(139,92,246,.2);color:#c4b5fd;border:1px solid rgba(139,92,246,.35)}
.poster-type-badge.anime{background:rgba(255,107,107,.2);color:#ff8080;border:1px solid rgba(255,107,107,.35)}

.poster-overlay{
  position:absolute;inset:0;opacity:0;transition:opacity .24s;
  background:linear-gradient(to top,rgba(11,12,20,.98) 0%,rgba(11,12,20,.5) 45%,transparent 100%);
  display:flex;flex-direction:column;align-items:center;justify-content:flex-end;
  padding:14px;gap:8px}
.poster-card:hover .poster-overlay{opacity:1}

.btn-play-big{
  width:52px;height:52px;border-radius:50%;border:2px solid rgba(255,255,255,.9);
  background:rgba(139,92,246,.9);color:#fff;font-size:1.15rem;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 4px 24px rgba(139,92,246,.65);transition:all .2s}
.btn-play-big:hover{background:#8B5CF6;transform:scale(1.12)}
.btn-play-big.loading{background:var(--s3);cursor:wait;pointer-events:none}
.pbig-spin{display:none;width:18px;height:18px;
  border:2.5px solid rgba(255,255,255,.2);border-top-color:#fff;
  border-radius:50%;animation:spin .7s linear infinite}
.btn-play-big.loading .pbig-icon{display:none}
.btn-play-big.loading .pbig-spin{display:block}

.overlay-src-row{display:flex;gap:5px;flex-wrap:wrap;justify-content:center}
.src-dot{padding:4px 9px;border:none;border-radius:5px;cursor:pointer;
  font-family:'Space Mono',monospace;font-size:.5rem;font-weight:700;
  letter-spacing:.04em;text-transform:uppercase;transition:all .15s}
.src-dot:hover{filter:brightness(1.2);transform:translateY(-1px)}
.src-dot.videasy{background:rgba(240,192,96,.18);color:#f0c060;border:1px solid rgba(240,192,96,.4)}
.src-dot.vidlink{background:rgba(160,108,240,.18);color:#a06cf0;border:1px solid rgba(160,108,240,.4)}
.src-dot.primesrc{background:rgba(52,211,153,.18);color:#34d399;border:1px solid rgba(52,211,153,.4)}

.poster-info{padding:10px 12px 12px;display:flex;flex-direction:column;gap:4px}
.poster-title{font-size:.78rem;font-weight:700;color:var(--text);
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
  overflow:hidden;line-height:1.4}
.poster-meta{font-family:'Space Mono',monospace;font-size:.57rem;color:var(--muted);
  display:flex;gap:8px;align-items:center}
.poster-rating{color:var(--gold)}

.ep-sel{display:flex;gap:4px;align-items:center;flex-wrap:wrap;margin-top:6px}
.ep-lbl{font-family:'Space Mono',monospace;font-size:.52rem;color:var(--muted2);
  text-transform:uppercase;flex-shrink:0}
.ep-inp{width:38px;padding:5px 6px;background:var(--s3);border:1px solid var(--border);
  border-radius:5px;color:var(--text);font-family:'Space Mono',monospace;font-size:.62rem;
  outline:none;text-align:center;-moz-appearance:textfield}
.ep-inp::-webkit-inner-spin-button{-webkit-appearance:none}
.ep-inp:focus{border-color:var(--acc)}
.ep-play{flex:1;min-width:0;padding:6px 8px;border:none;cursor:pointer;border-radius:5px;
  background:linear-gradient(135deg,#8B5CF6,#6d3ed4);color:#fff;
  font-family:'Syne',sans-serif;font-weight:800;font-size:.58rem;letter-spacing:.05em;
  text-transform:uppercase;transition:all .15s;
  display:flex;align-items:center;justify-content:center;gap:3px}
.ep-play:hover{filter:brightness(1.15)}
.ep-play.loading{opacity:.7;cursor:wait}
.ep-spin{display:none;width:7px;height:7px;
  border:1.5px solid rgba(255,255,255,.3);border-top-color:#fff;
  border-radius:50%;animation:spin .7s linear infinite}
.ep-play.loading .ep-lbl-txt{display:none}
.ep-play.loading .ep-spin{display:inline-block}

.search-empty{text-align:center;padding:100px 20px;color:var(--muted);
  font-family:'Syne',sans-serif;font-size:.85rem}
.search-empty .se-icon{font-size:4rem;display:block;margin-bottom:18px;opacity:.15}
.search-empty p{font-size:.75rem;color:var(--muted2);margin-top:8px}
.search-loading{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;
  padding:100px 20px;color:var(--muted);font-family:'Syne',sans-serif;font-size:.78rem}
.sload-spin{width:36px;height:36px;border:3px solid rgba(255,255,255,.07);
  border-top-color:var(--acc);border-radius:50%;animation:spin .75s linear infinite}
.search-result-count{font-family:'Space Mono',monospace;font-size:.58rem;
  color:var(--muted2);margin-bottom:4px;padding-top:4px}

#search-grid-wrap{padding-top:4px}

@media(max-width:760px){
  .poster-grid{grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px}
  .sv-tabs{gap:4px}
  .stab{padding:6px 12px;font-size:.64rem}}
@media(max-width:480px){
  .poster-grid{grid-template-columns:repeat(3,1fr);gap:8px}
  .sv-search-row{gap:6px}}

/* ── MegaPlay ── */
:root{
  --c-mp-dub:#ff6b6b;--c-mp-sub:#ff9f43;
}
.src-dot.mp-dub{background:rgba(255,107,107,.15);color:#ff6b6b;border:1px solid rgba(255,107,107,.4)}
.src-dot.mp-sub{background:rgba(255,159,67,.15);color:#ff9f43;border:1px solid rgba(255,159,67,.4)}
.overlay-src-row-2{margin-top:5px}
.ext-btn.mp-dub{background:linear-gradient(135deg,rgba(255,107,107,.18),rgba(255,107,107,.08));
  color:#ff6b6b;border:1px solid rgba(255,107,107,.35)}
.ext-btn.mp-sub{background:linear-gradient(135deg,rgba(255,159,67,.18),rgba(255,159,67,.08));
  color:#ff9f43;border:1px solid rgba(255,159,67,.35)}
.ext-btn.mp-dub:hover,.ext-btn.mp-sub:hover{
  filter:brightness(1.2);transform:translateY(-1px)}
.ext-divider-label{font-family:'Space Mono',monospace;font-size:.54rem;
  text-transform:uppercase;letter-spacing:.12em;color:var(--muted2);
  flex-basis:100%;margin:6px 0 2px}

/* ── Iframe modal (MegaPlay) ── */
.iframe-modal-bg{display:none;position:fixed;inset:0;z-index:2000;
  background:rgba(4,6,13,.93);backdrop-filter:blur(14px);
  align-items:center;justify-content:center;padding:16px}
.iframe-modal-bg.vis{display:flex}
.iframe-modal{position:relative;width:100%;max-width:1000px;
  background:var(--s1);border:1px solid var(--border2);border-radius:var(--r);
  overflow:hidden;box-shadow:0 32px 90px rgba(0,0,0,.85)}
.iframe-modal-hdr{display:flex;align-items:center;gap:10px;
  padding:10px 14px;border-bottom:1px solid var(--border);background:var(--s2)}
.iframe-modal-title{flex:1;font-size:.78rem;font-weight:700;color:var(--text);
  font-family:'Syne',sans-serif}
.iframe-wrap{position:relative;width:100%;aspect-ratio:16/9;background:#000}
.iframe-wrap iframe{position:absolute;inset:0;width:100%;height:100%;border:none}
.stab.active[id=stab-anime]{background:rgba(255,107,107,.13);
  border-color:rgba(255,107,107,.45);color:#ff6b6b}

/* ── Player layout with episode sidebar ── */
.player-layout{display:flex;gap:12px;align-items:flex-start}
.player-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:14px}

.ep-sidebar{
  width:230px;flex-shrink:0;display:none;flex-direction:column;
  background:var(--s1);border:1px solid var(--border);border-radius:var(--r);
  overflow:hidden;max-height:520px;
  position:sticky;top:16px}
.ep-sidebar.vis{display:flex}
.ep-sidebar-hdr{
  padding:11px 13px 10px;border-bottom:1px solid var(--border);
  background:var(--s2);flex-shrink:0}
.ep-sidebar-title{
  font-size:.68rem;font-weight:800;color:var(--text);letter-spacing:.02em;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:7px}
.ep-season-sel{
  width:100%;padding:6px 9px;background:var(--s3);border:1px solid var(--border);
  border-radius:var(--r3);color:var(--text);font-family:'Space Mono',monospace;
  font-size:.62rem;outline:none;cursor:pointer;transition:border-color .15s}
.ep-season-sel:focus{border-color:var(--acc)}
/* episode grid (shared by sidebar + anime panel) */
.ep-sidebar-list{
  flex:1;overflow-y:auto;padding:7px;
  display:grid;grid-template-columns:repeat(auto-fill,minmax(34px,1fr));
  gap:4px;align-content:start;
  scrollbar-width:thin;scrollbar-color:var(--muted2) transparent}
.ep-sidebar-list::-webkit-scrollbar{width:3px}
.ep-sidebar-list::-webkit-scrollbar-thumb{background:var(--muted2);border-radius:2px}
.ep-item{
  aspect-ratio:1;display:flex;align-items:center;justify-content:center;
  cursor:pointer;border-radius:7px;border:1.5px solid var(--border);
  background:var(--s2);color:var(--muted);
  font-family:'Space Mono',monospace;font-size:.58rem;font-weight:700;
  transition:all .13s;padding:0;line-height:1;user-select:none}
.ep-item:hover{background:rgba(139,92,246,.2);color:#c4b5fd;border-color:rgba(139,92,246,.5)}
.ep-item.active{
  background:var(--acc);color:#fff;border-color:var(--acc);
  box-shadow:0 0 10px rgba(139,92,246,.55);font-weight:800}
.ep-sidebar-loading{grid-column:1/-1;padding:18px;text-align:center;color:var(--muted);
  font-family:'Space Mono',monospace;font-size:.6rem}

/* ── Continue Watching ── */
.cw-section{margin-bottom:0}
.cw-hdr{display:flex;align-items:center;gap:10px;margin-bottom:10px}
.cw-hdr-title{font-family:'Syne',sans-serif;font-size:.82rem;font-weight:800;
  color:var(--text);letter-spacing:.02em;display:flex;align-items:center;gap:6px}
.cw-scroll{overflow-x:auto;scrollbar-width:thin;scrollbar-color:var(--muted2) transparent;
  padding-bottom:4px}
.cw-scroll::-webkit-scrollbar{height:3px}
.cw-scroll::-webkit-scrollbar-thumb{background:var(--muted2);border-radius:2px}
.cw-list{display:flex;gap:10px;min-width:min-content}
.cw-card{
  width:150px;flex-shrink:0;background:var(--s2);border:1px solid var(--border);
  border-radius:var(--r);overflow:hidden;transition:all .22s}
.cw-card:hover{border-color:rgba(139,92,246,.5);transform:translateY(-3px);
  box-shadow:0 14px 36px rgba(0,0,0,.55)}
.cw-poster{width:100%;aspect-ratio:2/3;background:var(--s3);overflow:hidden}
.cw-poster img{width:100%;height:100%;object-fit:cover}
.cw-info{padding:8px 9px 10px;display:flex;flex-direction:column;gap:3px}
.cw-title{font-size:.68rem;font-weight:700;color:var(--text);
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.35}
.cw-ep{font-family:'Space Mono',monospace;font-size:.62rem;font-weight:700;color:var(--acc);margin-top:1px}
.cw-src{font-family:'Space Mono',monospace;font-size:.5rem;color:var(--muted2)}
.cw-actions{display:flex;gap:4px;margin-top:6px}
.cw-actions .btn{flex:1;min-width:0;font-size:.54rem;padding:5px 6px}

/* ── Anime modal episode panel ── */
.iframe-modal-body{display:flex;overflow:hidden}
.iframe-modal .iframe-wrap{flex:1;min-width:0;position:relative;aspect-ratio:16/9;background:#000}
.iframe-modal .iframe-wrap iframe{position:absolute;inset:0;width:100%;height:100%;border:none}
.anime-ep-panel{
  width:196px;flex-shrink:0;display:flex;flex-direction:column;
  background:var(--s1);border-left:1px solid var(--border);
  overflow:hidden;max-height:540px}
.anime-ep-panel-hdr{
  padding:10px 13px;border-bottom:1px solid var(--border);background:var(--s2);
  display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.anime-ep-panel-title{font-size:.65rem;font-weight:800;color:var(--text);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
.anime-ep-list{
  flex:1;overflow-y:auto;padding:7px;
  display:grid;grid-template-columns:repeat(auto-fill,minmax(34px,1fr));
  gap:4px;align-content:start;
  scrollbar-width:thin;scrollbar-color:var(--muted2) transparent}
.anime-ep-list::-webkit-scrollbar{width:3px}
.anime-ep-list::-webkit-scrollbar-thumb{background:var(--muted2);border-radius:2px}
@media(max-width:700px){
  .player-layout{flex-direction:column}
  .ep-sidebar{width:100%;max-height:180px;position:static}
  .iframe-modal-body{flex-direction:column}
  .anime-ep-panel{width:100%;max-height:140px;border-left:none;border-top:1px solid var(--border)}}
</style>
</head>
<body>
<div class="shell">

  <!-- ── TOP BAR ── -->
  <div class="topbar">
    <div class="brand" onclick="goHome()" title="Home">
      <div class="brand-mark">&#x25B6;</div>
      <div>
        <div class="brand-name">FoxyPlay</div>
        <div class="brand-sub">Pro M3U8 Player</div>
      </div>
    </div>
    <div class="tb-spacer"></div>
    <span class="pill live"><span class="dot"></span>CF PROXY</span>
    <span class="pill btn" onclick="openSearch()">&#x1F50D; SEARCH</span>
    <span class="pill btn" onclick="openHeaders()">&#9881; HEADERS</span>
  </div>

  <!-- ── PLAYER VIEW ── -->
  <div id="player-view">

    <div class="url-card">
      <input id="url" class="url-input" type="text"
        placeholder="Paste a direct .m3u8 URL and press PLAY&#x2026;"
        onkeydown="if(event.key==='Enter') loadFromInput()"/>
      <button class="btn btn-primary" onclick="loadFromInput()">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21"/></svg>
        PLAY
      </button>
    </div>

    <!-- ── CONTINUE WATCHING ── -->
    <div id="cw-section" class="cw-section" style="display:none">
      <div class="cw-hdr">
        <span class="cw-hdr-title">&#x23F1; Continue Watching</span>
      </div>
      <div class="cw-scroll">
        <div class="cw-list" id="cw-list"></div>
      </div>
    </div>

    <div class="player-layout">

      <div class="player-main">
        <div class="player-card">
          <div class="player-wrap">
            <video id="video" controls playsinline></video>
            <div class="player-overlay" id="overlay">
              <svg width="72" height="72" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                <circle cx="12" cy="12" r="10"/>
                <polygon points="10 8 16 12 10 16 10 8" fill="currentColor" opacity=".5"/>
              </svg>
              <div class="ov-title">FoxyPlay</div>
              <p>Use <b>&#x1F50D; SEARCH</b> to find movies, TV shows &amp; anime,<br/>
              or paste a direct .m3u8 URL above and press PLAY.</p>
            </div>
            <div class="loader" id="loader"><div class="spinner"></div></div>
          </div>
          <div class="ctrl-bar">
            <div class="ctrl-info">
              <span id="src-badge" class="src-badge" style="display:none"></span>
              <span class="ctrl-title" id="now-playing">&#x2014; idle &#x2014;</span>
            </div>
            <span class="ctrl-stats" id="stats"></span>
            <div id="quality-wrap"></div>
            <button class="btn btn-ghost btn-sm" onclick="copyCurrentURL(this)">COPY URL</button>
            <button class="btn btn-ghost btn-sm" onclick="stopPlayer()">STOP</button>
          </div>
        </div>

        <div class="status-card fade" id="status"></div>

        <div class="streams-card" id="streamsc">
          <div class="streams-hdr">
            <h3>Extracted Streams</h3>
            <span class="tag acc" id="strm-source"></span>
            <span class="tag acc" id="strm-server"></span>
            <span class="tag green" id="strm-count"></span>
          </div>
          <div id="streams-list"></div>
        </div>
      </div><!-- /player-main -->

      <!-- TV / HLS Episode Sidebar -->
      <div class="ep-sidebar" id="ep-sidebar">
        <div class="ep-sidebar-hdr">
          <div class="ep-sidebar-title" id="ep-sidebar-title">Episodes</div>
          <select class="ep-season-sel" id="ep-season-sel" onchange="onSeasonChange(this)" style="display:none"></select>
        </div>
        <div class="ep-sidebar-list" id="ep-sidebar-list"></div>
      </div>

    </div><!-- /player-layout -->

  </div><!-- /player-view -->

  <!-- ── SEARCH VIEW ── -->
  <div id="search-view">
    <div class="sv-hero">
      <div class="sv-hero-inner">
        <div class="sv-search-row">
          <input id="sv-input" class="sv-input" type="text"
            placeholder="Search movies, TV shows &amp; anime&#x2026;"
            onkeydown="if(event.key==='Enter') doSearch()"/>
          <button class="btn btn-primary" onclick="doSearch()" style="flex-shrink:0;padding:13px 20px">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            SEARCH
          </button>
        </div>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <div class="sv-tabs">
            <button class="stab active" id="stab-movie" onclick="switchTab('movie')">&#x1F3AC; Movies</button>
            <button class="stab" id="stab-tv" onclick="switchTab('tv')">&#x1F4FA; TV Shows</button>
            <button class="stab" id="stab-anime" onclick="switchTab('anime')">&#x26A1; Anime</button>
          </div>
          <button class="btn btn-ghost btn-sm sv-back" onclick="closeSearch()" style="margin-left:auto">&#x2190; Back</button>
        </div>
      </div>
    </div>
    <div id="search-grid-wrap">
      <div class="search-empty">
        <span class="se-icon">&#x1F50D;</span>
        <strong>Find something to watch</strong>
        <p>Search movies, TV shows and anime above</p>
      </div>
    </div>
  </div><!-- /search-view -->

</div><!-- /shell -->

<!-- HEADERS MODAL -->
<div class="modal-bg" id="hdrModal">
  <div class="modal">
    <div class="mhdr">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--acc)" stroke-width="2">
        <circle cx="12" cy="12" r="3"/>
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
      </svg>
      <h3>Proxy Headers</h3>
      <button class="btn btn-ghost btn-sm" onclick="closeModal('hdrModal')">&#x2715;</button>
    </div>
    <div class="mbody">
      <div class="frm-grp">
        <label>Referer</label>
        <input id="hf-ref" type="text"/>
        <div class="frm-note">Sent as <code>Referer</code> to the upstream CDN.</div>
      </div>
      <div class="frm-grp">
        <label>Origin</label>
        <input id="hf-org" type="text"/>
        <div class="frm-note">Sent as <code>Origin</code> — usually the host without trailing slash.</div>
      </div>
      <div class="frm-grp">
        <label>User-Agent</label>
        <input id="hf-ua" type="text"/>
      </div>
      <div class="frm-grp">
        <label>Extra JSON Headers (optional)</label>
        <textarea id="hf-extra" placeholder='{"X-Token":"abc"}'></textarea>
        <div class="frm-note">Raw JSON object merged into headers.</div>
      </div>
      <div class="frm-grp">
        <label>Cloudflare Proxy Base URL</label>
        <input id="hf-proxy" type="text"/>
        <div class="frm-note">Endpoint: <code>/proxy?url=B64&amp;headers=B64</code></div>
      </div>
    </div>
    <div class="mftr">
      <button class="btn btn-red" onclick="resetHeaders()">RESET</button>
      <button class="btn btn-ghost btn-sm" onclick="closeModal('hdrModal')">CANCEL</button>
      <button class="btn btn-primary btn-sm" onclick="saveHeaders()">SAVE</button>
    </div>
  </div>
</div>


<script>
const CF_PROXY_BASE = "__CF_PROXY__";
const DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36";

const HDR_DEFAULTS = {
  Referer:"https://player.videasy.net/",
  Origin:"https://player.videasy.net",
  UserAgent:DEFAULT_UA,
  ExtraJSON:"",
  ProxyURL:CF_PROXY_BASE
};
const HK = "foxyplay_hdrs_v2";
const QK = "foxyplay_pref_q";

const SOURCES = {
  videasy: {
    label:"Videasy", icon:"\u2605", accent:"var(--c-videasy)",
    urlBase:"https://player.videasy.net/movie/",
    note:'Format: <code>https://player.videasy.net/movie/&lt;tmdb_id&gt;</code>',
    headers:{ Referer:"https://player.videasy.net/", Origin:"https://player.videasy.net" },
    badgeBg:"rgba(240,192,96,.15)", badgeColor:"#f0c060"
  },
  vidlink: {
    label:"VidLink", icon:"\u25CE", accent:"var(--c-vidlink)",
    urlBase:"https://vidlink.pro/movie/",
    note:'Format: <code>https://vidlink.pro/movie/&lt;tmdb_id&gt;</code> or <code>https://vidlink.pro/tv/&lt;tmdb_id&gt;/&lt;season&gt;/&lt;episode&gt;</code>',
    headers:{ Referer:"https://vidlink.pro/", Origin:"https://vidlink.pro" },
    badgeBg:"rgba(160,108,240,.15)", badgeColor:"#a06cf0"
  },
  primesrc: {
    label:"PrimeSrc", icon:"\u2B21", accent:"var(--c-primesrc)",
    urlBase:"https://primesrc.me/embed/movie?tmdb=",
    note:'Format: <code>https://primesrc.me/embed/movie?tmdb=&lt;id&gt;</code> or <code>https://primesrc.me/embed/tv?tmdb=&lt;id&gt;&amp;season=1&amp;episode=1</code>',
    headers:{ Referer:"https://primesrc.me/", Origin:"https://primesrc.me" },
    badgeBg:"rgba(54,217,138,.15)", badgeColor:"#36d98a"
  }
};

const SAMPLE_MOVIES = [
  ["Terminator 2","280"],["The Matrix","603"],["Inception","27205"],["Dark Knight","155"]
];

let HDR = loadHeaders();
let hlsInst = null, levelsCache = [];
let currentRawURL = null, currentProxyURL = null;
let currentSource = null;
let activeExtractor = null;

const $ = id => document.getElementById(id);
const esc = s => String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

function loadHeaders(){
  try{ const s=localStorage.getItem(HK); if(!s) return{...HDR_DEFAULTS};
    return{...HDR_DEFAULTS,...JSON.parse(s)}; }
  catch{ return{...HDR_DEFAULTS}; }
}
function openHeaders(){
  $('hf-ref').value=HDR.Referer;
  $('hf-org').value=HDR.Origin;
  $('hf-ua').value=HDR.UserAgent;
  $('hf-extra').value=HDR.ExtraJSON;
  $('hf-proxy').value=HDR.ProxyURL;
  $('hdrModal').classList.add('vis');
}
function saveHeaders(){
  const next={
    Referer:$('hf-ref').value.trim()||HDR_DEFAULTS.Referer,
    Origin:$('hf-org').value.trim()||HDR_DEFAULTS.Origin,
    UserAgent:$('hf-ua').value.trim()||HDR_DEFAULTS.UserAgent,
    ExtraJSON:$('hf-extra').value.trim(),
    ProxyURL:($('hf-proxy').value.trim()||HDR_DEFAULTS.ProxyURL).replace(/\/+$/,"")
  };
  if(next.ExtraJSON){ try{ JSON.parse(next.ExtraJSON); }
    catch{ alert("Extra Headers JSON is invalid."); return; } }
  HDR=next; localStorage.setItem(HK,JSON.stringify(HDR)); closeModal('hdrModal');
  if(currentRawURL) playStream(currentRawURL, $('now-playing').textContent, currentSource);
}
function resetHeaders(){ HDR={...HDR_DEFAULTS}; localStorage.removeItem(HK); openHeaders(); }

function buildHeadersDict(sourceKey){
  const h={
    Referer:HDR.Referer, Origin:HDR.Origin, "User-Agent":HDR.UserAgent
  };
  if(sourceKey && SOURCES[sourceKey]){
    Object.assign(h, SOURCES[sourceKey].headers);
  }
  if(HDR.ExtraJSON){ try{ Object.assign(h,JSON.parse(HDR.ExtraJSON)); }catch{} }
  return h;
}
function buildProxyURL(streamURL, sourceKey){
  const hdrs = buildHeadersDict(sourceKey);
  const u = encodeURIComponent(btoa(streamURL));
  const h = encodeURIComponent(btoa(JSON.stringify(hdrs)));
  return `${HDR.ProxyURL.replace(/\/+$/,"")}/proxy?url=${u}&headers=${h}`;
}

function setStatus(type,html){
  const el=$('status'); el.className=`status-card vis ${type}`; el.innerHTML=html;
}
function clearStatus(){ $('status').classList.remove('vis'); }

function getPrefH(){ const s=localStorage.getItem(QK); return s?parseInt(s,10):720; }
function savePref(h){ localStorage.setItem(QK,String(h)); }

function loadFromInput(){
  const u=$('url').value.trim();
  if(!u){ setStatus('err','Paste an .m3u8 URL first.'); return; }
  playStream(u,'Direct URL',null);
}

function playStream(url, label, sourceKey){
  currentRawURL=url; currentSource=sourceKey;
  currentProxyURL=buildProxyURL(url, sourceKey);
  $('overlay').classList.add('gone');
  $('loader').classList.add('vis');
  $('now-playing').textContent=label||url;
  $('stats').textContent='';
  clearStatus();
  $('quality-wrap').innerHTML='';
  const badge=$('src-badge');
  if(sourceKey && SOURCES[sourceKey]){
    const s=SOURCES[sourceKey];
    badge.textContent=s.label;
    badge.style.background=s.badgeBg;
    badge.style.color=s.badgeColor;
    badge.style.border=`1px solid ${s.badgeColor}55`;
    badge.style.display='';
  } else {
    badge.style.display='none';
  }
  mountHLS(currentProxyURL);
}

function stopPlayer(){
  if(hlsInst){ hlsInst.destroy(); hlsInst=null; }
  const v=$('video'); v.removeAttribute('src'); v.load();
  $('overlay').classList.remove('gone');
  $('loader').classList.remove('vis');
  $('now-playing').textContent='\u2014 idle \u2014';
  $('stats').textContent='';
  $('quality-wrap').innerHTML='';
  $('src-badge').style.display='none';
  currentRawURL=null; currentProxyURL=null; currentSource=null;
  hideEpSidebar();
}

function mountHLS(src){
  const v=$('video');
  if(hlsInst){ hlsInst.destroy(); hlsInst=null; }
  if(Hls.isSupported()){
    const hls=new Hls({ startLevel:-1, lowLatencyMode:false });
    hlsInst=hls;
    hls.loadSource(src);
    hls.attachMedia(v);
    hls.on(Hls.Events.MANIFEST_PARSED,(_,data)=>{
      $('loader').classList.remove('vis');
      const levels=data.levels.map((l,i)=>({
        i,h:l.height||0,b:l.bitrate||0,
        lbl:l.height?`${l.height}p`:(l.bitrate?`${Math.round(l.bitrate/1000)}k`:`L${i+1}`)
      }));
      const seen=new Map();
      levels.forEach(l=>{ if(!seen.has(l.lbl)) seen.set(l.lbl,l); });
      const uniq=Array.from(seen.values()).sort((a,b)=>a.h-b.h);
      levelsCache=uniq;
      const pref=getPrefH(); const chosen=pickLevel(uniq,pref);
      hls.currentLevel=chosen;
      renderQualityBar(uniq,chosen,pref);
      setStatus('ok',`\u2713 Loaded \u2014 ${uniq.length} quality level${uniq.length===1?'':'s'}`);
      v.play().catch(()=>{});
      updateStats(hls);
    });
    hls.on(Hls.Events.LEVEL_SWITCHED,()=>updateStats(hls));
    hls.on(Hls.Events.ERROR,(_,d)=>{
      if(d.fatal){
        $('loader').classList.remove('vis');
        setStatus('err',
          `Playback error: <b>${esc(d.type)}</b> \u2014 ${esc(d.details||'')}`+
          `<pre>${esc(d.reason||d.error?.message||'unknown')}</pre>`);
      }
    });
  } else if(v.canPlayType('application/vnd.apple.mpegurl')){
    v.src=src;
    v.addEventListener('loadedmetadata',()=>{
      $('loader').classList.remove('vis');
      setStatus('ok','\u2713 Native HLS (Safari)');
      v.play().catch(()=>{});
    });
    v.addEventListener('error',()=>{
      $('loader').classList.remove('vis');
      setStatus('err','Native HLS playback failed.');
    });
  } else {
    $('loader').classList.remove('vis');
    setStatus('err','HLS not supported in this browser.');
  }
}
function pickLevel(levels,pref){
  for(const t of [pref,720,1080,480,360]){
    const m=levels.find(l=>l.h===t); if(m) return m.i;
  }
  return levels.length?levels[Math.floor(levels.length/2)].i:-1;
}
function renderQualityBar(levels,chosen,pref){
  if(!levels.length){ $('quality-wrap').innerHTML=''; return; }
  const opts=[`<option value="-1">AUTO</option>`].concat(
    levels.map(l=>`<option value="${l.i}"${l.i===chosen?' selected':''}>${l.lbl}${l.h===pref?' \u2605':''}</option>`)
  ).join('');
  $('quality-wrap').innerHTML=
    `<select class="qsel" onchange="changeQuality(this)">${opts}</select>`;
}
function changeQuality(sel){
  const idx=parseInt(sel.value,10);
  if(hlsInst) hlsInst.currentLevel=idx;
  if(idx>=0){ const lv=levelsCache.find(l=>l.i===idx); if(lv&&lv.h) savePref(lv.h); }
}
function updateStats(hls){
  try{
    const lvl=hls.levels[hls.currentLevel];
    if(lvl){
      const kbps=lvl.bitrate?`${Math.round(lvl.bitrate/1000)}k`:'';
      const res=lvl.height?`${lvl.width||'?'}\xd7${lvl.height}`:'';
      $('stats').textContent=[res,kbps].filter(Boolean).join(' \u00b7 ');
    }
  }catch{}
}
async function copyCurrentURL(btn){
  const target=currentProxyURL||$('url').value.trim(); if(!target) return;
  try{
    await navigator.clipboard.writeText(target);
    const o=btn.textContent; btn.textContent='\u2713 COPIED';
    setTimeout(()=>btn.textContent=o,1400);
  }catch{}
}


function showStreams(streams, server, tmdb, sourceKey){
  $('streamsc').classList.add('vis');
  const s=SOURCES[sourceKey]||{label:sourceKey};
  $('strm-source').textContent=s.label||sourceKey;
  $('strm-server').textContent=server||'\u2014';
  $('strm-count').textContent=`${streams.length} stream${streams.length===1?'':'s'}`;
  $('streams-list').innerHTML=streams.map((u,i)=>`
    <div class="sitem">
      <span class="num">${String(i+1).padStart(2,'0')}</span>
      <span class="surl" title="${esc(u)}">${esc(u)}</span>
      <div class="acts">
        <button class="btn btn-primary btn-sm"
          onclick="playStream(${JSON.stringify(u)},${JSON.stringify(`${s.label}\u00b7${server}\u00b7TMDB ${tmdb}`)},${JSON.stringify(sourceKey)})">
          &#x25B6; PLAY
        </button>
        <button class="btn btn-ghost btn-sm" onclick="copyText(${JSON.stringify(u)},this)">COPY</button>
        <button class="btn btn-ghost btn-sm" onclick="copyText(buildProxyURL(${JSON.stringify(u)},${JSON.stringify(sourceKey)}),this)">PROXY</button>
      </div>
    </div>
  `).join('');
}

async function copyText(text,btn){
  try{
    await navigator.clipboard.writeText(text);
    const o=btn.textContent; btn.textContent='\u2713';
    setTimeout(()=>btn.textContent=o,1200);
  }catch{}
}

function closeModal(id){ $(id).classList.remove('vis'); }
document.querySelectorAll('.modal-bg').forEach(bg=>{
  bg.addEventListener('click',e=>{ if(e.target===bg) bg.classList.remove('vis'); });
});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape')
    document.querySelectorAll('.modal-bg.vis').forEach(m=>m.classList.remove('vis'));
});

/* ── SEARCH VIEW ── */
let searchResults = [];
let searchTab = 'movie';

function openSearch(){
  document.getElementById('player-view').style.display='none';
  document.getElementById('search-view').style.display='flex';
  setTimeout(()=>document.getElementById('sv-input').focus(), 80);
}
function closeSearch(){
  document.getElementById('search-view').style.display='none';
  document.getElementById('player-view').style.display='flex';
}
function goHome(){
  document.getElementById('search-view').style.display='none';
  document.getElementById('player-view').style.display='flex';
}

/* ═══════════════════════════════════════════
   EPISODE SIDEBAR — TV Shows (HLS sources)
   ═══════════════════════════════════════════ */
let currentEpState = null; // { type, sourceKey, movie, tmdbId, season, episode, seasons }

async function showTvEpSidebar(sourceKey, movie, season, episode){
  currentEpState = { type:'tv', sourceKey, movie, tmdbId: String(movie.id),
    season, episode, seasons: null };
  $('ep-sidebar-title').textContent = movie.title || 'Episodes';
  saveCW({ key:'tv_'+movie.id, type:'tv', title:movie.title,
    tmdbId:String(movie.id), season, episode, sourceKey,
    poster:movie.poster||'', movie });
  $('ep-sidebar-list').innerHTML = '<div class="ep-sidebar-loading">Loading episodes…</div>';
  $('ep-sidebar').classList.add('vis');
  try {
    const r = await fetch(`/player/api/tv-info?tmdb_id=${encodeURIComponent(String(movie.id))}`);
    if(!r.ok) throw new Error('TMDB error');
    const d = await r.json();
    if(!d.seasons || !d.seasons.length) throw new Error('No seasons found');
    currentEpState.seasons = d.seasons;
    const sel = $('ep-season-sel');
    sel.style.display = 'block';
    sel.innerHTML = d.seasons.map(s =>
      `<option value="${s.season_number}" ${s.season_number===season?'selected':''}>
        Season ${s.season_number} &nbsp;(${s.episode_count} eps)
      </option>`
    ).join('');
    const curSeason = d.seasons.find(s => s.season_number === season) || d.seasons[0];
    fillEpList($('ep-sidebar-list'), curSeason.episode_count, episode,
      (ep) => jumpTvEp(season, ep));
  } catch(e) {
    $('ep-sidebar-list').innerHTML = `<div class="ep-sidebar-loading">Could not load episode list.</div>`;
    $('ep-season-sel').style.display = 'none';
  }
}

function hideEpSidebar(){
  $('ep-sidebar').classList.remove('vis');
  $('ep-season-sel').style.display = 'none';
  currentEpState = null;
}

async function onSeasonChange(sel){
  if(!currentEpState || currentEpState.type !== 'tv') return;
  const newSeason = parseInt(sel.value, 10);
  const info = currentEpState.seasons?.find(s => s.season_number === newSeason);
  const total = info?.episode_count || 1;
  currentEpState.season = newSeason;
  currentEpState.episode = 1;
  fillEpList($('ep-sidebar-list'), total, 1, (ep) => jumpTvEp(newSeason, ep));
  await jumpTvEp(newSeason, 1);
}

async function jumpTvEp(season, episode){
  if(!currentEpState) return;
  currentEpState.season = season;
  currentEpState.episode = episode;
  // Update highlight
  document.querySelectorAll('#ep-sidebar-list .ep-item').forEach(el => el.classList.remove('active'));
  const it = document.getElementById('epsi-'+episode);
  if(it){ it.classList.add('active'); it.scrollIntoView({block:'nearest',behavior:'smooth'}); }
  // Re-extract
  const m = currentEpState.movie;
  const sourceKey = currentEpState.sourceKey;
  const s = SOURCES[sourceKey];
  const urls = _buildUrls(m, season, episode);
  const url = urls[sourceKey];
  const epLabel = ` S${String(season).padStart(2,'0')}E${String(episode).padStart(2,'0')}`;
  setStatus('info', `&#x23F3; Loading <b>${s.label}</b> &mdash; <b>${esc(m.title)}${epLabel}</b>&hellip;`);
  $('streamsc').classList.remove('vis');
  try {
    const d = await _doExtract(sourceKey, url);
    setStatus('ok', `&#x2713; <b>${s.label}</b> &mdash; ${d.streams.length} stream(s) &middot; server <b>${esc(d.server)}</b>`);
    showStreams(d.streams, d.server, d.tmdb_id, sourceKey);
    playStream(d.streams[0], `${s.label} \u00b7 ${esc(m.title)}${epLabel}`, sourceKey);
    saveCW({ key:'tv_'+m.id, type:'tv', title:m.title,
      tmdbId:String(m.id), season, episode, sourceKey:currentEpState.sourceKey,
      poster:m.poster||'', movie:m });
  } catch(e) {
    setStatus('err', `<b>${s.label}</b> failed: ${esc(String(e))}`);
  }
}

/* ═══════════════════════════════════════════
   EPISODE PANEL — Anime (MegaPlay iframe)
   ═══════════════════════════════════════════ */
let currentAnimeEpState = null; // { serverKey, movie, totalEps, episode }

function populateAnimeEpPanel(movie, serverKey, currentEp){
  const total = movie.episodes || 9999;
  currentAnimeEpState = { serverKey, movie, totalEps: total, episode: currentEp };
  $('anime-ep-panel-title').textContent = (total < 9999 ? `${total} Episodes` : 'Episodes');
  fillEpList($('anime-ep-list'), Math.min(total, 9999), currentEp,
    (ep) => jumpAnimeEp(ep));
  // Scroll to current ep after brief delay
  setTimeout(() => {
    const it = document.getElementById('epsi-a-'+currentEp);
    if(it) it.scrollIntoView({block:'center',behavior:'smooth'});
  }, 120);
}

function jumpAnimeEp(ep){
  if(!currentAnimeEpState) return;
  currentAnimeEpState.episode = ep;
  const m = currentAnimeEpState.movie;
  const s = MAL_SERVERS[currentAnimeEpState.serverKey];
  // Update highlight
  document.querySelectorAll('#anime-ep-list .ep-item').forEach(el => el.classList.remove('active'));
  const it = document.getElementById('epsi-a-'+ep);
  if(it){ it.classList.add('active'); it.scrollIntoView({block:'nearest',behavior:'smooth'}); }
  const url = s.build(m.mal_id, ep);
  showAnimeIframe(url, `${s.label} · ${esc(m.title)} · Ep ${ep}`, s);
  saveCW({ key:'anime_'+m.mal_id, type:'anime', title:m.title,
    malId:m.mal_id, episode:ep, serverKey:currentAnimeEpState.serverKey,
    poster:m.poster||'', movie:m, totalEps:currentAnimeEpState.totalEps });
}

/* ── Shared episode list renderer (grid squares) ── */
function fillEpList(container, total, activeEp, onClickFn){
  const isAnime = container.id === 'anime-ep-list';
  const pfx = isAnime ? 'epsi-a-' : 'epsi-';
  const buf = [];
  for(let i = 1; i <= total; i++){
    const fn = isAnime
      ? `jumpAnimeEp(${i})`
      : `jumpTvEp(${currentEpState?.season||1},${i})`;
    buf.push(`<button class="ep-item${i===activeEp?' active':''}" id="${pfx}${i}" onclick="${fn}" title="Episode ${i}">${i}</button>`);
  }
  container.innerHTML = buf.join('');
  if(activeEp >= 1){
    setTimeout(()=>{
      const it = document.getElementById(pfx+activeEp);
      if(it) it.scrollIntoView({block:'center',behavior:'smooth'});
    }, 80);
  }
}

/* ═══════════════════════════════════════════
   CONTINUE WATCHING  (localStorage)
   ═══════════════════════════════════════════ */
const CW_STORE = 'foxyplay_cw';

function saveCW(info){
  try{
    const cw = JSON.parse(localStorage.getItem(CW_STORE)||'{}');
    cw[info.key] = {...info, updatedAt: Date.now()};
    const trimmed = Object.fromEntries(
      Object.entries(cw).sort((a,b)=>b[1].updatedAt-a[1].updatedAt).slice(0,24));
    localStorage.setItem(CW_STORE, JSON.stringify(trimmed));
    renderCW();
  }catch(e){}
}

function removeCW(key){
  try{
    const cw = JSON.parse(localStorage.getItem(CW_STORE)||'{}');
    delete cw[key];
    localStorage.setItem(CW_STORE, JSON.stringify(cw));
    renderCW();
  }catch(e){}
}

function loadCW(){
  try{ return JSON.parse(localStorage.getItem(CW_STORE)||'{}'); }catch(e){ return {}; }
}

function renderCW(){
  const section = document.getElementById('cw-section');
  if(!section) return;
  const cw = loadCW();
  const entries = Object.entries(cw).sort((a,b)=>b[1].updatedAt-a[1].updatedAt);
  if(!entries.length){ section.style.display='none'; return; }
  section.style.display='';
  document.getElementById('cw-list').innerHTML = entries.map(([key,item])=>{
    const epLabel = item.type==='tv'
      ? `S${String(item.season).padStart(2,'0')}E${String(item.episode).padStart(2,'0')}`
      : `EP ${item.episode}`;
    const srcLabel = item.sourceKey
      ? (SOURCES[item.sourceKey]?.label||item.sourceKey)
      : (item.serverKey ? (MAL_SERVERS[item.serverKey]?.label||item.serverKey) : '');
    const poster = item.poster
      ? `<img src="${esc(item.poster)}" alt="" loading="lazy">`
      : `<div style="display:flex;align-items:center;justify-content:center;height:100%;font-size:2rem;color:var(--muted2)">&#x25B6;</div>`;
    return `<div class="cw-card">
      <div class="cw-poster">${poster}</div>
      <div class="cw-info">
        <div class="cw-title" title="${esc(item.title)}">${esc(item.title)}</div>
        <div class="cw-ep">${epLabel}</div>
        <div class="cw-src">${esc(srcLabel)}</div>
        <div class="cw-actions">
          <button class="btn btn-primary btn-sm" onclick="resumeCW('${key}')">&#x25B6; RESUME</button>
          <button class="btn btn-ghost btn-sm" onclick="removeCW('${key}')">&#x2715;</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

async function resumeCW(key){
  const cw = loadCW();
  const item = cw[key]; if(!item) return;
  if(item.type==='tv'){
    const m = item.movie;
    const sourceKey = item.sourceKey;
    const season = item.season;
    const episode = item.episode;
    const s = SOURCES[sourceKey];
    const urls = _buildUrls(m, season, episode);
    const url = urls[sourceKey];
    const epLabel = ` S${String(season).padStart(2,'0')}E${String(episode).padStart(2,'0')}`;
    setStatus('info',`&#x23F3; Resuming <b>${s.label}</b> &mdash; <b>${esc(m.title)}${epLabel}</b>&hellip;`);
    $('streamsc').classList.remove('vis');
    try{
      const d = await _doExtract(sourceKey, url);
      setStatus('ok',`&#x2713; <b>${s.label}</b> &mdash; ${d.streams.length} stream(s) &middot; server <b>${esc(d.server)}</b>`);
      showStreams(d.streams, d.server, d.tmdb_id, sourceKey);
      playStream(d.streams[0], `${s.label} \u00b7 ${esc(m.title)}${epLabel}`, sourceKey);
      showTvEpSidebar(sourceKey, m, season, episode);
    }catch(e){
      setStatus('err',`Resume failed: ${esc(String(e))}`);
    }
  } else if(item.type==='anime'){
    const m = item.movie;
    const serverKey = item.serverKey;
    const ep = item.episode;
    const s = MAL_SERVERS[serverKey];
    const url = s.build(m.mal_id, ep);
    showAnimeIframe(url, `${s.label} · ${esc(m.title)} · Ep ${ep}`, s);
    populateAnimeEpPanel(m, serverKey, ep);
  }
}
// Boot CW
document.addEventListener('DOMContentLoaded', renderCW);
function switchTab(tab){
  searchTab=tab;
  document.getElementById('stab-movie').classList.toggle('active',tab==='movie');
  document.getElementById('stab-tv').classList.toggle('active',tab==='tv');
  document.getElementById('stab-anime').classList.toggle('active',tab==='anime');
  const q=document.getElementById('sv-input').value.trim();
  if(q) doSearch();
}
async function doSearch(){
  if(searchTab==='anime'){ await doAnimeSearch(); return; }
  const q=document.getElementById('sv-input').value.trim();
  const wrap=document.getElementById('search-grid-wrap');
  if(!q){wrap.innerHTML='<div class="search-empty"><span class="se-icon">&#x1F50D;</span>Enter a title above to search</div>';return;}
  wrap.innerHTML='<div class="search-loading"><div class="sload-spin"></div>&nbsp;Searching TMDB&hellip;</div>';
  try{
    const r=await fetch(`/player/api/search?q=${encodeURIComponent(q)}&media_type=${searchTab}`);
    const d=await r.json();
    if(!r.ok){wrap.innerHTML=`<div class="search-empty"><span class="se-icon">&#x26A0;</span>${esc(d.detail?.error||'Search failed')}</div>`;return;}
    searchResults=d.results||[];
    renderGrid(d.results,d.total);
  }catch(e){
    wrap.innerHTML=`<div class="search-empty"><span class="se-icon">&#x26A0;</span>Network error: ${esc(String(e))}</div>`;
  }
}
function renderGrid(results,total){
  const wrap=document.getElementById('search-grid-wrap');
  if(!results||!results.length){wrap.innerHTML='<div class="search-empty"><span class="se-icon">&#x1F3AC;</span>No results found</div>';return;}
  const count=total>results.length?`<div class="search-result-count">Showing ${results.length} of ${total} results</div>`:'';
  const cards=results.map((m,i)=>{
    const poster=m.poster
      ?`<img src="${esc(m.poster)}" alt="" loading="lazy" onerror="this.parentElement.innerHTML='<div class=poster-ph>&#x1F3AC;</div>'">`
      :`<div class="poster-ph">&#x1F3AC;</div>`;
    const rating=m.rating?`<span class="poster-rating">&#x2605; ${m.rating}</span>`:'';
    const year=m.year?`<span>${esc(m.year)}</span>`:'';
    const isTV=(m.type||searchTab)==='tv';
    const typeLbl=isTV?'TV':'MOVIE';
    const typeClass=isTV?'tv':'movie';
    const epSel=isTV?`
      <div class="ep-sel">
        <span class="ep-lbl">S</span><input class="ep-inp" type="number" value="1" min="1" id="ep-s-${i}"/>
        <span class="ep-lbl">E</span><input class="ep-inp" type="number" value="1" min="1" id="ep-e-${i}"/>
        <button class="ep-play" onclick="smartExtract(${i},this)">
          <span class="ep-lbl-txt">&#x25B6; PLAY</span><span class="ep-spin"></span>
        </button>
      </div>`:'';
    const playBig=!isTV?`<button class="btn-play-big" onclick="smartExtract(${i},this)"><span class="pbig-icon">&#x25B6;</span><span class="pbig-spin"></span></button>`:'';
    return `<div class="poster-card">
      <div class="poster-img-wrap">
        ${poster}
        <span class="poster-type-badge ${typeClass}">${typeLbl}</span>
        <div class="poster-overlay">
          ${playBig}
          <div class="overlay-src-row">
            <button class="src-dot videasy" onclick="quickExtract('videasy',${i},this)">&#x2605; Videasy</button>
            <button class="src-dot vidlink" onclick="quickExtract('vidlink',${i},this)">&#x25CE; VidLink</button>
            <button class="src-dot primesrc" onclick="quickExtract('primesrc',${i},this)">&#x2B21; PrimeSrc</button>
          </div>
        </div>
      </div>
      <div class="poster-info">
        <div class="poster-title" title="${esc(m.title)}">${esc(m.title)}</div>
        <div class="poster-meta">${year}${rating}</div>
        ${epSel}
      </div>
    </div>`;
  }).join('');
  wrap.innerHTML=count+`<div class="poster-grid">${cards}</div>`;
}
function _buildUrls(m,season,episode){
  const id=m.id, isTV=(m.type||searchTab)==='tv';
  if(isTV){const s=season||1,e=episode||1;return{
    videasy:`https://player.videasy.net/tv/${id}/${s}/${e}?color=8B5CF6&nextEpisode=true&episodeSelector=true&autoplayNextEpisode=true`,
    vidlink:`https://vidlink.pro/tv/${id}/${s}/${e}`,
    primesrc:`https://primesrc.me/embed/tv?tmdb=${id}&season=${s}&episode=${e}`};}
  return{
    videasy:`https://player.videasy.net/movie/${id}`,
    vidlink:`https://vidlink.pro/movie/${id}`,
    primesrc:`https://primesrc.me/embed/movie?tmdb=${id}`};
}
async function _doExtract(sourceKey,url){
  const r=await fetch('/player/api/extract',{method:'POST',
    headers:{'Content-Type':'application/json'},body:JSON.stringify({source:sourceKey,url})});
  const d=await r.json();
  if(!r.ok) throw new Error(d.detail?.error||d.error||'unknown');
  if(!d.streams||!d.streams.length) throw new Error('No streams found');
  return d;
}
async function smartExtract(idx,btn){
  const m=searchResults[idx]; if(!m) return;
  const isTV=(m.type||searchTab)==='tv';
  const season=isTV?parseInt(document.getElementById('ep-s-'+idx)?.value||1,10)||1:null;
  const episode=isTV?parseInt(document.getElementById('ep-e-'+idx)?.value||1,10)||1:null;
  const urls=_buildUrls(m,season,episode);
  const epLabel=isTV?` S${String(season).padStart(2,'0')}E${String(episode).padStart(2,'0')}`:'';
  btn.classList.add('loading'); btn.disabled=true;
  closeSearch();
  $('streamsc').classList.remove('vis');
  const queue=[{key:'videasy',url:urls.videasy},{key:'vidlink',url:urls.vidlink},{key:'primesrc',url:urls.primesrc}];
  const errors=[];
  for(const {key,url} of queue){
    const s=SOURCES[key];
    setStatus('info',`&#x23F3; Trying <b>${s.label}</b> for <b>${esc(m.title)}${epLabel}</b>&hellip;`);
    try{
      const d=await _doExtract(key,url);
      setStatus('ok',`&#x2713; <b>${s.label}</b> &mdash; ${d.streams.length} stream${d.streams.length===1?'':'s'} &middot; server <b>${esc(d.server)}</b>`);
      showStreams(d.streams,d.server,d.tmdb_id,key);
      playStream(d.streams[0],`${s.label} \u00b7 ${esc(m.title)}${epLabel}`,key);
      if(isTV) showTvEpSidebar(key, m, season||1, episode||1);
      else hideEpSidebar();
      btn.classList.remove('loading'); btn.disabled=false; return;
    }catch(e){errors.push(`${s.label}: ${e.message}`);}
  }
  setStatus('err',`All sources failed for <b>${esc(m.title)}</b>:<pre>${errors.join('\n')}</pre>`);
  btn.classList.remove('loading'); btn.disabled=false;
}
async function quickExtract(sourceKey,idx,btn){
  const m=searchResults[idx]; if(!m) return;
  const isTV=(m.type||searchTab)==='tv';
  const season=isTV?parseInt(document.getElementById('ep-s-'+idx)?.value||1,10)||1:null;
  const episode=isTV?parseInt(document.getElementById('ep-e-'+idx)?.value||1,10)||1:null;
  const urls=_buildUrls(m,season,episode);
  const url=urls[sourceKey];
  const s=SOURCES[sourceKey];
  const epLabel=isTV?` S${String(season).padStart(2,'0')}E${String(episode).padStart(2,'0')}`:'';
  btn.disabled=true;
  closeSearch();
  const mainBtn=document.getElementById('btn-'+sourceKey);
  if(mainBtn) mainBtn.classList.add('loading');
  setStatus('info',`&#x23F3; Extracting via <b>${s.label}</b> &mdash; <b>${esc(m.title)}${epLabel}</b>&hellip;`);
  $('streamsc').classList.remove('vis');
  try{
    const d=await _doExtract(sourceKey,url);
    setStatus('ok',`&#x2713; <b>${s.label}</b> &mdash; ${d.streams.length} stream${d.streams.length===1?'':'s'} on server <b>${esc(d.server)}</b>`);
    showStreams(d.streams,d.server,d.tmdb_id,sourceKey);
    playStream(d.streams[0],`${s.label} \u00b7 ${esc(m.title)}${epLabel}`,sourceKey);
    if(isTV) showTvEpSidebar(sourceKey, m, season||1, episode||1);
    else hideEpSidebar();
  }catch(e){
    setStatus('err',`<b>${s.label}</b> failed: ${esc(String(e))}`);
  }finally{
    btn.disabled=false;
    if(mainBtn) mainBtn.classList.remove('loading');
  }
}

/* ─── MAL ID MODAL (for main page extractor buttons) ─── */
let malModalServer = null;
function openMalModal(serverKey){
  malModalServer = serverKey;
  const s = MAL_SERVERS[serverKey];
  document.getElementById('mal-modal-title').textContent = s.label + ' — Enter Anime';
  document.getElementById('mal-modal-badge').textContent = s.label;
  document.getElementById('mal-modal-badge').style.color = s.color;
  document.getElementById('mal-modal-badge').style.background = s.color + '22';
  document.getElementById('mal-mal-id').value = '';
  document.getElementById('mal-ep').value = '1';
  document.getElementById('malModal').classList.add('vis');
  setTimeout(()=>document.getElementById('mal-mal-id').focus(), 80);
}
function closeMalModal(){ document.getElementById('malModal').classList.remove('vis'); }
function runMalModal(){
  const malId = parseInt(document.getElementById('mal-mal-id').value.trim(), 10);
  const ep    = parseInt(document.getElementById('mal-ep').value, 10) || 1;
  if (!malId || isNaN(malId)){ alert('Enter a valid MAL ID'); return; }
  const s   = MAL_SERVERS[malModalServer];
  const url = s.build(malId, ep);
  closeMalModal();
  showAnimeIframe(url, `${s.label} · MAL ${malId} · Ep ${ep}`, s);
}

function showAnimeIframe(url, label, srv){
  const badge = document.getElementById('aframe-server-badge');
  badge.textContent = srv.label;
  badge.style.color = srv.color;
  badge.style.background = srv.color + '22';
  badge.style.border = `1px solid ${srv.color}55`;
  document.getElementById('aframe-title').textContent = label;
  document.getElementById('aframe-iframe').src = url;
  document.getElementById('animeFrameModal').classList.add('vis');
}
function closeAnimeFrame(){
  document.getElementById('animeFrameModal').classList.remove('vis');
  document.getElementById('aframe-iframe').src = '';
}

const MAL_SERVERS = {
  'mp-dub':{ label:'MegaPlay DUB', color:'#ff6b6b', build:(malId,ep)=>`https://megaplay.buzz/stream/mal/${malId}/${ep}/dub` },
  'mp-sub':{ label:'MegaPlay SUB', color:'#ff9f43', build:(malId,ep)=>`https://megaplay.buzz/stream/mal/${malId}/${ep}/sub` },
};

/* ─── ANIME SEARCH (Jikan) ─── */
let animeResults = [];
async function doAnimeSearch(){
  const q = document.getElementById('sv-input').value.trim();
  const wrap = document.getElementById('search-grid-wrap');
  if(!q){wrap.innerHTML='<div class="search-empty"><span class="se-icon">&#x1F3CC;</span>Enter an anime title to search</div>';return;}
  wrap.innerHTML='<div class="search-loading"><div class="sload-spin"></div>&nbsp;Searching Jikan&hellip;</div>';
  try{
    const r = await fetch(`/player/api/anime-search?q=${encodeURIComponent(q)}`);
    const d = await r.json();
    if(!r.ok){wrap.innerHTML=`<div class="search-empty"><span class="se-icon">&#x26A0;</span>${esc(d.detail?.error||'Search failed')}</div>`;return;}
    animeResults = d.results || [];
    renderAnimeGrid(animeResults, d.total);
  }catch(e){
    wrap.innerHTML=`<div class="search-empty"><span class="se-icon">&#x26A0;</span>Network error: ${esc(String(e))}</div>`;
  }
}
function renderAnimeGrid(results, total){
  const wrap = document.getElementById('search-grid-wrap');
  if(!results||!results.length){wrap.innerHTML='<div class="search-empty"><span class="se-icon">&#x1F3CC;</span>No anime found</div>';return;}
  const count = total>results.length?`<div class="search-result-count">Showing ${results.length} of ${total} results</div>`:'';
  const cards = results.map((m,i)=>{
    const poster = m.poster
      ?`<img src="${esc(m.poster)}" alt="" loading="lazy" onerror="this.parentElement.innerHTML='<div class=poster-ph>&#x1F3CC;</div>'">`
      :`<div class="poster-ph">&#x1F3CC;</div>`;
    const rating = m.rating?`<span class="poster-rating">&#x2605; ${m.rating}</span>`:'';
    const year   = m.year?`<span>${esc(m.year)}</span>`:'';
    return `<div class="poster-card">
      <div class="poster-img-wrap">
        ${poster}
        <span class="poster-type-badge anime">ANIME</span>
        <div class="poster-overlay">
          <div class="overlay-src-row">
            <button class="src-dot mp-dub" onclick="openAnimeFrame('mp-dub',${i},this)">&#x1F1FA;&#x1F1F8; DUB</button>
            <button class="src-dot mp-sub" onclick="openAnimeFrame('mp-sub',${i},this)">SUB</button>
          </div>
        </div>
      </div>
      <div class="poster-info">
        <div class="poster-title" title="${esc(m.title)}">${esc(m.title)}</div>
        <div class="poster-meta">${year}${rating}</div>
        <div class="ep-sel">
          <span class="ep-lbl">EP</span>
          <input class="ep-inp" type="number" value="1" min="1" max="${m.episodes||999}" id="ep-a-${i}"/>
          <button class="ep-play" onclick="openAnimeFrame('mp-dub',${i},this)">
            <span class="ep-lbl-txt">&#x25B6; PLAY</span><span class="ep-spin"></span>
          </button>
        </div>
      </div>
    </div>`;
  }).join('');
  wrap.innerHTML = count+`<div class="poster-grid">${cards}</div>`;
}
function openAnimeFrame(serverKey, idx, btn){
  const m = animeResults[idx]; if(!m) return;
  const ep = parseInt(document.getElementById('ep-a-'+idx)?.value||1,10)||1;
  const s  = MAL_SERVERS[serverKey];
  const url = s.build(m.mal_id, ep);
  closeSearch();
  showAnimeIframe(url, `${s.label} · ${esc(m.title)} · Ep ${ep}`, s);
  populateAnimeEpPanel(m, serverKey, ep);
  saveCW({ key:'anime_'+m.mal_id, type:'anime', title:m.title,
    malId:m.mal_id, episode:ep, serverKey, poster:m.poster||'',
    movie:m, totalEps:m.episodes||9999 });
}
async function quickExtractAnime(sourceKey, idx, btn){
  const m = animeResults[idx]; if(!m) return;
  const ep = parseInt(document.getElementById('ep-a-'+idx)?.value||1,10)||1;
  let url;
  if(sourceKey==='videasy') url=`https://player.videasy.net/anime/${m.mal_id}/${ep}`;
  else if(sourceKey==='vidlink') url=`https://vidlink.pro/anime/${m.mal_id}/${ep}`;
  else url=`https://primesrc.me/embed/anime?id=${m.mal_id}&episode=${ep}`;
  const s = SOURCES[sourceKey];
  btn.disabled=true;
  closeSearch();
  const mainBtn=document.getElementById('btn-'+sourceKey);
  if(mainBtn) mainBtn.classList.add('loading');
  setStatus('info',`&#x23F3; Extracting via <b>${s.label}</b> &mdash; <b>${esc(m.title)} Ep ${ep}</b>&hellip;`);
  $('streamsc').classList.remove('vis');
  try{
    const d=await _doExtract(sourceKey,url);
    setStatus('ok',`&#x2713; <b>${s.label}</b> &mdash; ${d.streams.length} stream(s) on server <b>${esc(d.server)}</b>`);
    showStreams(d.streams,d.server,m.mal_id,sourceKey);
    playStream(d.streams[0],`${s.label} \u00b7 ${esc(m.title)} Ep ${ep}`,sourceKey);
  }catch(e){
    setStatus('err',`<b>${s.label}</b> failed: ${esc(String(e))}`);
  }finally{
    btn.disabled=false;
    if(mainBtn) mainBtn.classList.remove('loading');
  }
}
</script>

<!-- ANIME IFRAME MODAL -->
<div class="iframe-modal-bg" id="animeFrameModal">
  <div class="iframe-modal" style="max-width:1160px">
    <div class="iframe-modal-hdr">
      <span id="aframe-server-badge" style="font-size:.62rem;padding:3px 9px;border-radius:4px;font-family:'Space Mono',monospace;font-weight:700;letter-spacing:.05em"></span>
      <span class="iframe-modal-title" id="aframe-title">&mdash;</span>
      <button class="btn btn-ghost btn-sm" onclick="closeAnimeFrame()">&#x2715;</button>
    </div>
    <div class="iframe-modal-body">
      <div class="iframe-wrap">
        <iframe id="aframe-iframe" src="" width="100%" height="100%" frameborder="0" scrolling="no" allowfullscreen></iframe>
      </div>
      <div class="anime-ep-panel" id="anime-ep-panel">
        <div class="anime-ep-panel-hdr">
          <span class="anime-ep-panel-title" id="anime-ep-panel-title">Episodes</span>
        </div>
        <div class="anime-ep-list" id="anime-ep-list"></div>
      </div>
    </div>
  </div>
</div>

<!-- MAL ID MODAL (main page quick-play) -->
<div class="modal-bg" id="malModal">
  <div class="modal">
    <div class="mhdr">
      <span id="mal-modal-badge" style="font-size:.65rem;padding:3px 9px;border-radius:4px;font-family:'Space Mono',monospace;font-weight:700;letter-spacing:.05em"></span>
      <h3 id="mal-modal-title">Enter Anime</h3>
      <button class="btn btn-ghost btn-sm" onclick="closeMalModal()">&#x2715;</button>
    </div>
    <div class="mbody">
      <div class="frm-grp">
        <label>MAL ID</label>
        <input id="mal-mal-id" type="number" min="1" placeholder="e.g. 21 (One Piece)"
          onkeydown="if(event.key==='Enter') runMalModal()"/>
        <div class="frm-note">Find the MAL ID on <a href="https://myanimelist.net" target="_blank" style="color:var(--acc)">myanimelist.net</a> — it&#x2019;s the number in the URL.</div>
      </div>
      <div class="frm-grp">
        <label>Episode</label>
        <input id="mal-ep" type="number" value="1" min="1"
          onkeydown="if(event.key==='Enter') runMalModal()"/>
      </div>
    </div>
    <div class="mftr">
      <button class="btn btn-ghost btn-sm" onclick="closeMalModal()">CANCEL</button>
      <button class="btn btn-primary" onclick="runMalModal()">&#x25B6; PLAY</button>
    </div>
  </div>
</div>

</body>
</html>"""

HTML = HTML.replace("__CF_PROXY__", CF_PROXY_BASE)


# ══════════════════════════════════════════════════════════════════════════════
#  FASTAPI APP
# ══════════════════════════════════════════════════════════════════════════════

app = FastAPI(title="FoxyPlay — Pro M3U8 Player")


class ExtractReq(BaseModel):
    source: str
    url: str


@app.get("/", response_class=HTMLResponse)
def root():
    return HTMLResponse(HTML)


@app.get("/player/api/healthz")
def healthz():
    return {
        "status": "ok",
        "cf_proxy": CF_PROXY_BASE,
        "extractors": list(EXTRACTORS.keys()),
    }


@app.get("/player/api/tv-info")
def api_tv_info(tmdb_id: str = ""):
    if not tmdb_id.strip():
        raise HTTPException(status_code=400, detail={"error": "tmdb_id required"})
    url = f"{TMDB_API_BASE}/tv/{tmdb_id.strip()}"
    params: dict = {}
    if not TMDB_API_KEY.startswith("eyJ"):
        params["api_key"] = TMDB_API_KEY
    try:
        r = requests.get(url, headers=_tmdb_headers(), params=params, timeout=10)
        r.raise_for_status()
        data = r.json()
        seasons = []
        for s in data.get("seasons", []):
            sn = s.get("season_number", 0)
            ec = s.get("episode_count", 0)
            if sn > 0 and ec > 0:
                seasons.append({
                    "season_number": sn,
                    "episode_count": ec,
                    "name": s.get("name") or f"Season {sn}",
                })
        return {"title": data.get("name", ""), "seasons": seasons}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail={"error": f"{type(e).__name__}: {e}"})


@app.get("/player/api/search")
def api_search(q: str = "", media_type: str = "movie", page: int = 1):
    if not q.strip():
        raise HTTPException(status_code=400, detail={"error": "Query is required"})
    if media_type not in ("movie", "tv"):
        raise HTTPException(status_code=400, detail={"error": "media_type must be 'movie' or 'tv'"})
    try:
        return tmdb_search(q.strip(), media_type, page)
    except ExtractorError as e:
        raise HTTPException(status_code=500, detail={"error": str(e)})
    except Exception as e:
        raise HTTPException(status_code=500, detail={"error": f"{e.__class__.__name__}: {e}"})


@app.get("/player/api/anime-search")
def api_anime_search(q: str = "", page: int = 1):
    if not q.strip():
        raise HTTPException(status_code=400, detail={"error": "Query is required"})
    try:
        return jikan_search(q.strip(), page)
    except Exception as e:
        raise HTTPException(status_code=500, detail={"error": f"{e.__class__.__name__}: {e}"})


@app.post("/player/api/extract")
def api_extract(body: ExtractReq):
    source = body.source.lower().strip()
    fn = EXTRACTORS.get(source)
    if not fn:
        raise HTTPException(
            status_code=400,
            detail={"error": f"Unknown source '{source}'. Valid: {list(EXTRACTORS)}"}
        )
    try:
        result = fn(body.url)
        return result
    except ExtractorError as e:
        msg = str(e)
        head, _, tail = msg.partition("\n")
        raise HTTPException(
            status_code=502,
            detail={"error": head, "tried": tail or ""}
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"error": f"{type(e).__name__}: {e}"}
        )


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 26046))
    uvicorn.run(app, host="0.0.0.0", port=port)
