import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { getTrending, getPopular, searchAnime, type AnimeMedia } from "@/lib/api";
import { Search, Play, Star, TrendingUp, Flame } from "lucide-react";

function AnimeCard({ anime, onClick }: { anime: AnimeMedia; onClick: () => void }) {
  const title = anime.title.english || anime.title.romaji;
  const score = anime.averageScore ? (anime.averageScore / 10).toFixed(1) : null;

  return (
    <div
      onClick={onClick}
      className="group relative rounded-xl overflow-hidden cursor-pointer bg-card border border-border transition-all duration-200 hover:scale-[1.03] hover:shadow-xl hover:border-primary/40"
    >
      <div className="relative aspect-[2/3] overflow-hidden">
        <img
          src={anime.coverImage.extraLarge || anime.coverImage.large}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <div className="bg-primary/90 rounded-full p-3 shadow-lg">
            <Play className="w-6 h-6 text-white fill-white" />
          </div>
        </div>
        {score && (
          <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-sm text-yellow-400 text-xs font-bold px-2 py-1 rounded-md flex items-center gap-1">
            <Star className="w-3 h-3 fill-yellow-400" />
            {score}
          </div>
        )}
        {anime.format && (
          <div className="absolute top-2 left-2 bg-primary/80 text-white text-xs font-semibold px-2 py-1 rounded-md">
            {anime.format}
          </div>
        )}
      </div>
      <div className="p-3">
        <h3 className="text-sm font-semibold text-foreground line-clamp-2 leading-tight">{title}</h3>
        <div className="flex items-center gap-2 mt-1.5">
          {anime.seasonYear && (
            <span className="text-xs text-muted-foreground">{anime.seasonYear}</span>
          )}
          {anime.episodes && (
            <span className="text-xs text-muted-foreground">{anime.episodes} eps</span>
          )}
          {anime.status === "RELEASING" && (
            <span className="text-xs text-green-400 font-medium">Airing</span>
          )}
        </div>
      </div>
    </div>
  );
}

function AnimeGrid({ anime, isLoading }: { anime: AnimeMedia[]; isLoading: boolean }) {
  const [, setLocation] = useLocation();
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {Array.from({ length: 18 }).map((_, i) => (
          <div key={i} className="rounded-xl bg-card border border-border overflow-hidden animate-pulse">
            <div className="aspect-[2/3] bg-muted" />
            <div className="p-3 space-y-2">
              <div className="h-3 bg-muted rounded w-full" />
              <div className="h-3 bg-muted rounded w-2/3" />
            </div>
          </div>
        ))}
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
      {anime.map((a) => (
        <AnimeCard key={a.id} anime={a} onClick={() => setLocation(`/watch/${a.id}`)} />
      ))}
    </div>
  );
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [activeTab, setActiveTab] = useState<"trending" | "popular">("trending");

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 400);
    return () => clearTimeout(t);
  }, [query]);

  const isSearching = debouncedQuery.trim().length > 0;

  const { data: trendingData, isLoading: trendingLoading } = useQuery({
    queryKey: ["trending"],
    queryFn: () => getTrending(),
    enabled: !isSearching,
  });

  const { data: popularData, isLoading: popularLoading } = useQuery({
    queryKey: ["popular"],
    queryFn: () => getPopular(),
    enabled: !isSearching,
  });

  const { data: searchData, isLoading: searchLoading } = useQuery({
    queryKey: ["search", debouncedQuery],
    queryFn: () => searchAnime(debouncedQuery),
    enabled: isSearching,
  });

  const displayAnime = isSearching
    ? searchData?.media ?? []
    : activeTab === "trending"
    ? trendingData?.media ?? []
    : popularData?.media ?? [];

  const isLoading = isSearching ? searchLoading : activeTab === "trending" ? trendingLoading : popularLoading;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="max-w-screen-2xl mx-auto px-4 py-3 flex items-center gap-4">
          <div className="flex items-center gap-2 mr-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Play className="w-4 h-4 text-white fill-white" />
            </div>
            <span className="text-xl font-bold text-foreground tracking-tight">FoxyPlay</span>
          </div>
          <div className="flex-1 relative max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <input
              type="search"
              placeholder="Search anime..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
            />
          </div>
        </div>
      </header>

      <main className="max-w-screen-2xl mx-auto px-4 py-6">
        {!isSearching && (
          <div className="flex items-center gap-1 mb-6">
            <button
              onClick={() => setActiveTab("trending")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === "trending"
                  ? "bg-primary text-white shadow-lg shadow-primary/25"
                  : "text-muted-foreground hover:text-foreground hover:bg-card"
              }`}
            >
              <Flame className="w-4 h-4" />
              Trending
            </button>
            <button
              onClick={() => setActiveTab("popular")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === "popular"
                  ? "bg-primary text-white shadow-lg shadow-primary/25"
                  : "text-muted-foreground hover:text-foreground hover:bg-card"
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              Popular
            </button>
          </div>
        )}

        {isSearching && (
          <div className="mb-5">
            <h2 className="text-lg font-semibold text-foreground">
              Results for{" "}
              <span className="text-primary">"{debouncedQuery}"</span>
              {searchData && (
                <span className="ml-2 text-sm text-muted-foreground font-normal">
                  ({searchData.total} found)
                </span>
              )}
            </h2>
          </div>
        )}

        <AnimeGrid anime={displayAnime} isLoading={isLoading} />

        {!isLoading && displayAnime.length === 0 && isSearching && (
          <div className="text-center py-24">
            <Search className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground text-lg">No results for "{debouncedQuery}"</p>
          </div>
        )}
      </main>
    </div>
  );
}
