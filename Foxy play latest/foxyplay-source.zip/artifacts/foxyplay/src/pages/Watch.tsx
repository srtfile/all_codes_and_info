import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getAnimeById, type AnimeMedia } from "@/lib/api";
import { SERVERS, DEFAULT_SERVER_ID, type Server } from "@/lib/servers";
import { ArrowLeft, Star, Calendar, Tv2, ChevronLeft, ChevronRight, Info } from "lucide-react";

function ServerGroup({
  label,
  servers,
  activeId,
  onSelect,
  disabled,
}: {
  label: string;
  servers: Server[];
  activeId: string;
  onSelect: (id: string) => void;
  disabled: boolean;
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-2 px-1">{label}</p>
      <div className="flex flex-wrap gap-2">
        {servers.map((s) => (
          <button
            key={s.id}
            onClick={() => onSelect(s.id)}
            disabled={disabled}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${
              activeId === s.id
                ? "bg-primary border-primary text-white shadow-md shadow-primary/30"
                : "bg-card border-border text-foreground hover:border-primary/50 hover:bg-card/80 disabled:opacity-50 disabled:cursor-not-allowed"
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function EpisodeGrid({
  total,
  current,
  onSelect,
}: {
  total: number;
  current: number;
  onSelect: (ep: number) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = document.getElementById(`ep-btn-${current}`);
    if (el) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [current]);

  const [page, setPage] = useState(0);
  const PAGE_SIZE = 100;
  const pages = Math.ceil(total / PAGE_SIZE);
  const start = page * PAGE_SIZE + 1;
  const end = Math.min((page + 1) * PAGE_SIZE, total);
  const eps = Array.from({ length: end - start + 1 }, (_, i) => start + i);

  useEffect(() => {
    const p = Math.floor((current - 1) / PAGE_SIZE);
    setPage(p);
  }, [current]);

  return (
    <div>
      {pages > 1 && (
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          {Array.from({ length: pages }, (_, i) => {
            const s = i * PAGE_SIZE + 1;
            const e = Math.min((i + 1) * PAGE_SIZE, total);
            return (
              <button
                key={i}
                onClick={() => setPage(i)}
                className={`text-xs px-2.5 py-1 rounded-md border transition-all ${
                  page === i
                    ? "bg-primary border-primary text-white"
                    : "bg-card border-border text-muted-foreground hover:border-primary/50"
                }`}
              >
                {s}-{e}
              </button>
            );
          })}
        </div>
      )}
      <div
        ref={containerRef}
        className="flex flex-wrap gap-1.5 max-h-52 overflow-y-auto pr-1"
        style={{ scrollbarWidth: "thin" }}
      >
        {eps.map((ep) => (
          <button
            key={ep}
            id={`ep-btn-${ep}`}
            onClick={() => onSelect(ep)}
            className={`w-10 h-10 rounded-lg text-sm font-semibold transition-all border flex-shrink-0 ${
              ep === current
                ? "bg-primary border-primary text-white shadow-md shadow-primary/30"
                : "bg-card border-border text-foreground hover:border-primary/50 hover:bg-muted"
            }`}
          >
            {ep}
          </button>
        ))}
      </div>
    </div>
  );
}

function InfoBadge({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${className}`}>
      {children}
    </span>
  );
}

export default function Watch() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const animeId = Number(id);

  const { data: anime, isLoading } = useQuery<AnimeMedia>({
    queryKey: ["anime", animeId],
    queryFn: () => getAnimeById(animeId),
    enabled: !!animeId,
  });

  const [ep, setEp] = useState(1);
  const [serverId, setServerId] = useState(DEFAULT_SERVER_ID);
  const [showDesc, setShowDesc] = useState(false);

  const totalEps = anime?.episodes ?? 1;
  const malId = anime?.idMal ?? 0;
  const title = anime ? (anime.title.english || anime.title.romaji) : "Loading...";

  const activeServer = SERVERS.find((s) => s.id === serverId) || SERVERS[0];
  const playerUrl = anime && malId
    ? activeServer.buildUrl(animeId, malId, ep)
    : anime
    ? activeServer.buildUrl(animeId, 0, ep)
    : null;

  const malRequired = activeServer.group === "mal";
  const playerDisabled = malRequired && !malId;

  const generalServers = SERVERS.filter((s) => s.group === "general");
  const malServers = SERVERS.filter((s) => s.group === "mal");

  const score = anime?.averageScore ? (anime.averageScore / 10).toFixed(1) : null;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="max-w-screen-xl mx-auto px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <div className="w-px h-5 bg-border" />
          <h1 className="text-sm font-semibold text-foreground truncate">{title}</h1>
          <span className="ml-auto text-sm text-muted-foreground">
            Ep {ep}{totalEps > 1 ? ` / ${totalEps}` : ""}
          </span>
        </div>
      </header>

      <div className="max-w-screen-xl mx-auto px-4 py-4 space-y-4">
        <div className="relative w-full bg-black rounded-2xl overflow-hidden shadow-2xl" style={{ aspectRatio: "16/9" }}>
          {playerDisabled ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-card">
              <Info className="w-10 h-10 text-muted-foreground" />
              <p className="text-muted-foreground text-sm text-center px-8">
                MAL ID not available for this anime.<br />
                MegaPlay &amp; VidWish require a MAL ID.
              </p>
            </div>
          ) : isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-card">
              <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : playerUrl ? (
            <iframe
              key={`${serverId}-${ep}`}
              src={playerUrl}
              className="absolute inset-0 w-full h-full"
              allowFullScreen
              allow="autoplay; fullscreen; picture-in-picture"
              title={`${title} Episode ${ep}`}
              referrerPolicy="no-referrer"
            />
          ) : null}
        </div>

        <div className="flex items-center justify-between">
          <button
            onClick={() => setEp((p) => Math.max(1, p - 1))}
            disabled={ep <= 1}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-card border border-border text-sm font-medium hover:border-primary/50 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
            Prev
          </button>
          <span className="text-sm font-semibold text-foreground">Episode {ep}</span>
          <button
            onClick={() => setEp((p) => Math.min(totalEps, p + 1))}
            disabled={ep >= totalEps}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-card border border-border text-sm font-medium hover:border-primary/50 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          >
            Next
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-card border border-border rounded-xl p-4 space-y-4">
              <div>
                <h2 className="font-semibold text-xs uppercase tracking-widest text-muted-foreground mb-3">Servers</h2>
                <div className="space-y-4">
                  <ServerGroup
                    label="General"
                    servers={generalServers}
                    activeId={serverId}
                    onSelect={setServerId}
                    disabled={isLoading}
                  />
                  <ServerGroup
                    label="MAL / Jikan (Anime Only)"
                    servers={malServers}
                    activeId={serverId}
                    onSelect={setServerId}
                    disabled={isLoading || !malId}
                  />
                  {!malId && anime && (
                    <p className="text-xs text-amber-400/80 flex items-center gap-1.5 mt-1">
                      <Info className="w-3.5 h-3.5 flex-shrink-0" />
                      MAL ID unavailable — MegaPlay &amp; VidWish disabled for this title
                    </p>
                  )}
                </div>
              </div>
            </div>

            {totalEps > 1 && (
              <div className="bg-card border border-border rounded-xl p-4">
                <h2 className="font-semibold text-xs uppercase tracking-widest text-muted-foreground mb-3">
                  Episodes ({totalEps})
                </h2>
                <EpisodeGrid total={totalEps} current={ep} onSelect={setEp} />
              </div>
            )}
          </div>

          <div>
            {isLoading ? (
              <div className="bg-card border border-border rounded-xl p-4 space-y-3 animate-pulse">
                <div className="flex gap-4">
                  <div className="w-24 h-36 rounded-lg bg-muted flex-shrink-0" />
                  <div className="flex-1 space-y-2 pt-1">
                    <div className="h-4 bg-muted rounded w-full" />
                    <div className="h-4 bg-muted rounded w-3/4" />
                    <div className="h-3 bg-muted rounded w-1/2 mt-3" />
                  </div>
                </div>
              </div>
            ) : anime ? (
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="flex gap-4 mb-4">
                  <img
                    src={anime.coverImage.large}
                    alt={title}
                    className="w-24 rounded-lg object-cover flex-shrink-0 shadow-md"
                  />
                  <div className="flex-1 min-w-0">
                    <h2 className="font-bold text-foreground text-base leading-snug mb-1">{title}</h2>
                    {anime.title.native && (
                      <p className="text-xs text-muted-foreground mb-2">{anime.title.native}</p>
                    )}
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {score && (
                        <InfoBadge className="bg-yellow-500/15 text-yellow-400 border border-yellow-500/20">
                          <Star className="w-3 h-3 mr-1 fill-yellow-400" />
                          {score}
                        </InfoBadge>
                      )}
                      {anime.format && (
                        <InfoBadge className="bg-primary/15 text-primary border border-primary/20">
                          <Tv2 className="w-3 h-3 mr-1" />
                          {anime.format}
                        </InfoBadge>
                      )}
                      {anime.seasonYear && (
                        <InfoBadge className="bg-muted text-muted-foreground border border-border">
                          <Calendar className="w-3 h-3 mr-1" />
                          {anime.seasonYear}
                        </InfoBadge>
                      )}
                      {anime.status === "RELEASING" && (
                        <InfoBadge className="bg-green-500/15 text-green-400 border border-green-500/20">
                          Airing
                        </InfoBadge>
                      )}
                      {malId ? (
                        <InfoBadge className="bg-blue-500/15 text-blue-400 border border-blue-500/20">
                          MAL #{malId}
                        </InfoBadge>
                      ) : null}
                    </div>
                  </div>
                </div>

                {anime.genres.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {anime.genres.slice(0, 6).map((g) => (
                      <span
                        key={g}
                        className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground border border-border"
                      >
                        {g}
                      </span>
                    ))}
                  </div>
                )}

                {anime.description && (
                  <div>
                    <p
                      className={`text-sm text-muted-foreground leading-relaxed ${
                        !showDesc ? "line-clamp-3" : ""
                      }`}
                    >
                      {anime.description.replace(/<[^>]*>/g, "")}
                    </p>
                    {anime.description.length > 200 && (
                      <button
                        onClick={() => setShowDesc((p) => !p)}
                        className="text-xs text-primary hover:underline mt-1"
                      >
                        {showDesc ? "Show less" : "Read more"}
                      </button>
                    )}
                  </div>
                )}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
