export interface Server {
  id: string;
  label: string;
  group: "general" | "mal";
  buildUrl: (anilistId: number, malId: number, ep: number) => string;
}

export const SERVERS: Server[] = [
  {
    id: "videasy",
    label: "Videasy",
    group: "general",
    buildUrl: (anilistId, _malId, ep) =>
      `https://player.videasy.net/anime/${anilistId}/${ep}`,
  },
  {
    id: "vidlink",
    label: "VidLink",
    group: "general",
    buildUrl: (anilistId, _malId, ep) =>
      `https://vidlink.pro/anime/${anilistId}/${ep}`,
  },
  {
    id: "primsrc",
    label: "PrimSrc",
    group: "general",
    buildUrl: (anilistId, _malId, ep) =>
      `https://vidsrc.to/embed/anime/${anilistId}/${ep}`,
  },
  {
    id: "mp-dub",
    label: "MegaPlay DUB",
    group: "mal",
    buildUrl: (_anilistId, malId, ep) =>
      `https://megaplay.buzz/stream/mal/${malId}/${ep}/dub`,
  },
  {
    id: "mp-sub",
    label: "MegaPlay SUB",
    group: "mal",
    buildUrl: (_anilistId, malId, ep) =>
      `https://megaplay.buzz/stream/mal/${malId}/${ep}/sub`,
  },
  {
    id: "vw-dub",
    label: "VidWish DUB",
    group: "mal",
    buildUrl: (_anilistId, malId, ep) =>
      `https://vidwish.live/stream/mal/${malId}/${ep}/dub`,
  },
  {
    id: "vw-sub",
    label: "VidWish SUB",
    group: "mal",
    buildUrl: (_anilistId, malId, ep) =>
      `https://vidwish.live/stream/mal/${malId}/${ep}/sub`,
  },
];

export const DEFAULT_SERVER_ID = "videasy";
