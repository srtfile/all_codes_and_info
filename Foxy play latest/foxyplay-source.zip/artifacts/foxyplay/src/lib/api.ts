const ANILIST = "https://graphql.anilist.co";
const JIKAN = "https://api.jikan.moe/v4";

export interface AnimeMedia {
  id: number;
  idMal: number | null;
  title: {
    romaji: string;
    english: string | null;
    native: string;
  };
  coverImage: {
    large: string;
    extraLarge: string;
    color: string | null;
  };
  bannerImage: string | null;
  description: string | null;
  episodes: number | null;
  status: string;
  genres: string[];
  averageScore: number | null;
  season: string | null;
  seasonYear: number | null;
  format: string | null;
  studios: {
    nodes: { name: string }[];
  };
}

const MEDIA_FRAGMENT = `
  id
  idMal
  title { romaji english native }
  coverImage { large extraLarge color }
  bannerImage
  description(asHtml: false)
  episodes
  status
  genres
  averageScore
  season
  seasonYear
  format
  studios(isMain: true) { nodes { name } }
`;

async function anilist<T>(query: string, variables: Record<string, unknown> = {}): Promise<T> {
  const res = await fetch(ANILIST, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ query, variables }),
  });
  if (!res.ok) throw new Error(`AniList error: ${res.status}`);
  const json = await res.json();
  if (json.errors) throw new Error(json.errors[0]?.message || "AniList error");
  return json.data as T;
}

export async function getTrending(page = 1): Promise<{ media: AnimeMedia[]; total: number }> {
  const data = await anilist<{ Page: { media: AnimeMedia[]; pageInfo: { total: number } } }>(
    `query($page: Int) {
      Page(page: $page, perPage: 24) {
        pageInfo { total }
        media(type: ANIME, sort: TRENDING_DESC, isAdult: false) { ${MEDIA_FRAGMENT} }
      }
    }`,
    { page }
  );
  return { media: data.Page.media, total: data.Page.pageInfo.total };
}

export async function getPopular(page = 1): Promise<{ media: AnimeMedia[] }> {
  const data = await anilist<{ Page: { media: AnimeMedia[] } }>(
    `query($page: Int) {
      Page(page: $page, perPage: 24) {
        media(type: ANIME, sort: POPULARITY_DESC, isAdult: false) { ${MEDIA_FRAGMENT} }
      }
    }`,
    { page }
  );
  return { media: data.Page.media };
}

export async function searchAnime(query: string, page = 1): Promise<{ media: AnimeMedia[]; total: number }> {
  const data = await anilist<{ Page: { media: AnimeMedia[]; pageInfo: { total: number } } }>(
    `query($search: String, $page: Int) {
      Page(page: $page, perPage: 24) {
        pageInfo { total }
        media(type: ANIME, search: $search, isAdult: false, sort: SEARCH_MATCH) { ${MEDIA_FRAGMENT} }
      }
    }`,
    { search: query, page }
  );
  return { media: data.Page.media, total: data.Page.pageInfo.total };
}

export async function getAnimeById(id: number): Promise<AnimeMedia> {
  const data = await anilist<{ Media: AnimeMedia }>(
    `query($id: Int) {
      Media(id: $id, type: ANIME) { ${MEDIA_FRAGMENT} }
    }`,
    { id }
  );
  return data.Media;
}

const jikanCache: Record<string, unknown> = {};
async function jikanFetch(path: string) {
  if (jikanCache[path]) return jikanCache[path];
  await new Promise((r) => setTimeout(r, 400));
  const res = await fetch(JIKAN + path);
  if (!res.ok) return null;
  const data = await res.json();
  jikanCache[path] = data;
  return data;
}

export async function getEpisodeCount(malId: number): Promise<number> {
  const data = await jikanFetch(`/anime/${malId}`) as { data?: { episodes?: number } } | null;
  return data?.data?.episodes ?? 0;
}
